import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

enum BadgeStatus { active, inactive, background, warning }

class StatusBadgeWidget extends StatelessWidget {
  final BadgeStatus status;
  final String? customLabel;

  const StatusBadgeWidget({super.key, required this.status, this.customLabel});

  @override
  Widget build(BuildContext context) {
    final config = _config(context);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: config.$1,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: config.$2, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            customLabel ?? config.$3,
            style: GoogleFonts.manrope(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: config.$2,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  (Color, Color, String) _config(BuildContext context) {
    switch (status) {
      case BadgeStatus.active:
        return (const Color(0xFFB7E4C7), const Color(0xFF1B5E35), 'ACTIVE');
      case BadgeStatus.inactive:
        return (const Color(0xFFF0F0F0), const Color(0xFF9E9E9E), 'INACTIVE');
      case BadgeStatus.background:
        return (const Color(0xFFE3F2FD), const Color(0xFF1565C0), 'BACKGROUND');
      case BadgeStatus.warning:
        return (const Color(0xFFFFF3E0), const Color(0xFFB45309), 'WARNING');
    }
  }
}
