import 'package:flutter/material.dart';

import '../presentation/main_screen/main_screen.dart';
import '../presentation/settings_screen/settings_screen.dart';
import '../presentation/onboarding_screen/onboarding_screen.dart';
import '../presentation/recording_screen/recording_screen.dart';
import '../presentation/recordings_library_screen/recordings_library_screen.dart';

class AppRoutes {
  static const String initial = '/';
  static const String onboardingScreen = '/onboarding-screen';
  static const String mainScreen = '/main-screen';
  static const String settingsScreen = '/settings-screen';
  static const String recordingScreen = '/recording-screen';
  static const String recordingsLibraryScreen = '/recordings-library';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const OnboardingScreen(),
    onboardingScreen: (context) => const OnboardingScreen(),
    mainScreen: (context) => const MainScreen(),
    settingsScreen: (context) => const SettingsScreen(),
    recordingScreen: (context) => const RecordingScreen(),
    recordingsLibraryScreen: (context) => const RecordingsLibraryScreen(),
  };
}
