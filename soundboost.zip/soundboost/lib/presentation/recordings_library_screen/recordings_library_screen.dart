import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';

import '../../theme/app_theme.dart';
import '../../widgets/custom_icon_widget.dart';

// ── Shared recording model ────────────────────────────────────────────────────

class RecordingItem {
  final String name;
  final int durationSeconds;
  final String format;
  final DateTime savedAt;
  final String? filePath; // null on web

  const RecordingItem({
    required this.name,
    required this.durationSeconds,
    required this.format,
    required this.savedAt,
    this.filePath,
  });
}

// ── Global in-memory store (shared between recording screen and library) ──────

class RecordingsStore {
  RecordingsStore._();
  static final RecordingsStore instance = RecordingsStore._();

  final List<RecordingItem> _items = [];
  final _controller = StreamController<List<RecordingItem>>.broadcast();

  Stream<List<RecordingItem>> get stream => _controller.stream;
  List<RecordingItem> get items => List.unmodifiable(_items);

  void add(RecordingItem item) {
    _items.insert(0, item);
    _controller.add(_items);
  }

  void remove(RecordingItem item) {
    _items.remove(item);
    _controller.add(_items);
  }

  void dispose() => _controller.close();
}

// ── Screen ────────────────────────────────────────────────────────────────────

class RecordingsLibraryScreen extends StatefulWidget {
  const RecordingsLibraryScreen({super.key});

  @override
  State<RecordingsLibraryScreen> createState() =>
      _RecordingsLibraryScreenState();
}

class _RecordingsLibraryScreenState extends State<RecordingsLibraryScreen> {
  late StreamSubscription<List<RecordingItem>> _sub;
  List<RecordingItem> _recordings = [];
  String _sortBy = 'date'; // 'date' | 'name' | 'format'
  String _filterFormat = 'All'; // 'All' | 'WAV' | 'MP3'

  @override
  void initState() {
    super.initState();
    _recordings = List.from(RecordingsStore.instance.items);
    _sub = RecordingsStore.instance.stream.listen((items) {
      if (mounted) setState(() => _recordings = List.from(items));
    });
  }

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }

  List<RecordingItem> get _filtered {
    var list = _filterFormat == 'All'
        ? List<RecordingItem>.from(_recordings)
        : _recordings.where((r) => r.format == _filterFormat).toList();

    switch (_sortBy) {
      case 'name':
        list.sort((a, b) => a.name.compareTo(b.name));
        break;
      case 'format':
        list.sort((a, b) => a.format.compareTo(b.format));
        break;
      default:
        list.sort((a, b) => b.savedAt.compareTo(a.savedAt));
    }
    return list;
  }

  String _fmtDuration(int s) {
    final m = (s ~/ 60).toString().padLeft(2, '0');
    final sec = (s % 60).toString().padLeft(2, '0');
    return '$m:$sec';
  }

  String _fmtDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    if (diff.inDays == 1) return 'Yesterday';
    return '${dt.day}/${dt.month}/${dt.year}';
  }

  Future<void> _shareRecording(RecordingItem item) async {
    HapticFeedback.lightImpact();
    if (kIsWeb) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'On web, use the download button to save "${item.name}" then share from your device.',
          ),
          backgroundColor: AppTheme.primary,
          duration: const Duration(seconds: 3),
        ),
      );
      return;
    }
    if (item.filePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('File path unavailable for sharing.'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }
    try {
      await Share.shareXFiles(
        [
          XFile(
            item.filePath!,
            mimeType: item.format == 'WAV' ? 'audio/wav' : 'audio/mpeg',
          ),
        ],
        subject: item.name,
        text: 'Processed audio from SoundBoost: ${item.name}',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Share failed: $e'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  void _showExportOptions(RecordingItem item) {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _ExportBottomSheet(
        item: item,
        onShare: () {
          Navigator.pop(ctx);
          _shareRecording(item);
        },
        onDelete: () {
          Navigator.pop(ctx);
          _deleteRecording(item);
        },
      ),
    );
  }

  void _deleteRecording(RecordingItem item) {
    HapticFeedback.mediumImpact();
    RecordingsStore.instance.remove(item);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('"${item.name}" removed from library.'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final filtered = _filtered;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context, theme),
            _buildFilterBar(theme),
            Expanded(
              child: filtered.isEmpty
                  ? _buildEmptyState(theme)
                  : ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                      itemCount: filtered.length,
                      itemBuilder: (_, i) => _RecordingLibraryTile(
                        item: filtered[i],
                        theme: theme,
                        fmtDuration: _fmtDuration,
                        fmtDate: _fmtDate,
                        onShare: () => _shareRecording(filtered[i]),
                        onMore: () => _showExportOptions(filtered[i]),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context, ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline,
                  width: 1.5,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'arrow_back',
                color: theme.colorScheme.onSurface,
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Recordings Library',
                  style: GoogleFonts.manrope(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: theme.colorScheme.onSurface,
                    letterSpacing: -0.4,
                  ),
                ),
                Text(
                  '${_recordings.length} recording${_recordings.length == 1 ? '' : 's'}',
                  style: GoogleFonts.manrope(
                    fontSize: 11,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Sort button
          GestureDetector(
            onTap: () => _showSortSheet(context, theme),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline,
                  width: 1.5,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'sort',
                color: theme.colorScheme.onSurface,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterBar(ThemeData theme) {
    final formats = ['All', 'WAV', 'MP3'];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
      child: Row(
        children: formats.map((f) {
          final selected = _filterFormat == f;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () => setState(() => _filterFormat = f),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: selected
                      ? AppTheme.primary
                      : theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: selected
                        ? AppTheme.primary
                        : theme.colorScheme.outline,
                    width: 1.5,
                  ),
                ),
                child: Text(
                  f,
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: selected
                        ? Colors.white
                        : theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: AppTheme.primary.withAlpha(20),
                shape: BoxShape.circle,
              ),
              child: const CustomIconWidget(
                iconName: 'folder_open',
                color: AppTheme.primary,
                size: 32,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'No recordings yet',
              style: GoogleFonts.manrope(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Head to Recording Studio to capture\nprocessed audio sessions.',
              textAlign: TextAlign.center,
              style: GoogleFonts.manrope(
                fontSize: 12,
                color: theme.colorScheme.onSurfaceVariant,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSortSheet(BuildContext context, ThemeData theme) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: theme.colorScheme.outline, width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sort by',
              style: GoogleFonts.manrope(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: theme.colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 12),
            ...['date', 'name', 'format'].map((s) {
              final labels = {
                'date': 'Date (newest first)',
                'name': 'Name (A–Z)',
                'format': 'Format',
              };
              final icons = {
                'date': 'schedule',
                'name': 'sort_by_alpha',
                'format': 'audio_file',
              };
              return GestureDetector(
                onTap: () {
                  setState(() => _sortBy = s);
                  Navigator.pop(ctx);
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: _sortBy == s
                        ? AppTheme.primary.withAlpha(20)
                        : theme.colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _sortBy == s
                          ? AppTheme.primary.withAlpha(80)
                          : Colors.transparent,
                      width: 1.5,
                    ),
                  ),
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: icons[s]!,
                        color: _sortBy == s
                            ? AppTheme.primary
                            : theme.colorScheme.onSurfaceVariant,
                        size: 18,
                      ),
                      const SizedBox(width: 12),
                      Text(
                        labels[s]!,
                        style: GoogleFonts.manrope(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: _sortBy == s
                              ? AppTheme.primary
                              : theme.colorScheme.onSurface,
                        ),
                      ),
                      if (_sortBy == s) ...[
                        const Spacer(),
                        CustomIconWidget(
                          iconName: 'check_circle',
                          color: AppTheme.primary,
                          size: 16,
                        ),
                      ],
                    ],
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

// ── Recording tile ────────────────────────────────────────────────────────────

class _RecordingLibraryTile extends StatelessWidget {
  final RecordingItem item;
  final ThemeData theme;
  final String Function(int) fmtDuration;
  final String Function(DateTime) fmtDate;
  final VoidCallback onShare;
  final VoidCallback onMore;

  const _RecordingLibraryTile({
    required this.item,
    required this.theme,
    required this.fmtDuration,
    required this.fmtDate,
    required this.onShare,
    required this.onMore,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.outline, width: 1.5),
      ),
      child: Row(
        children: [
          // Icon
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppTheme.primary.withAlpha(20),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const CustomIconWidget(
              iconName: 'audio_file',
              color: AppTheme.primary,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.name,
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    _Chip(label: item.format, color: AppTheme.primary),
                    const SizedBox(width: 6),
                    Text(
                      fmtDuration(item.durationSeconds),
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 10,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '·',
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      fmtDate(item.savedAt),
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          // Share button
          GestureDetector(
            onTap: onShare,
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: AppTheme.primary.withAlpha(20),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const CustomIconWidget(
                iconName: 'share',
                color: AppTheme.primary,
                size: 16,
              ),
            ),
          ),
          const SizedBox(width: 6),
          // More options
          GestureDetector(
            onTap: onMore,
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: 'more_vert',
                color: theme.colorScheme.onSurfaceVariant,
                size: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final Color color;

  const _Chip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withAlpha(25),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        label,
        style: GoogleFonts.manrope(
          fontSize: 9,
          fontWeight: FontWeight.w800,
          color: color,
        ),
      ),
    );
  }
}

// ── Export bottom sheet ───────────────────────────────────────────────────────

class _ExportBottomSheet extends StatelessWidget {
  final RecordingItem item;
  final VoidCallback onShare;
  final VoidCallback onDelete;

  const _ExportBottomSheet({
    required this.item,
    required this.onShare,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.colorScheme.outline, width: 1.5),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.primary.withAlpha(20),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const CustomIconWidget(
                  iconName: 'audio_file',
                  color: AppTheme.primary,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name,
                      style: GoogleFonts.manrope(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: theme.colorScheme.onSurface,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      item.format,
                      style: GoogleFonts.manrope(
                        fontSize: 11,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(),
          const SizedBox(height: 12),
          // Actions
          _SheetAction(
            icon: 'share',
            label: 'Share via messaging / email',
            subtitle: 'Send to WhatsApp, Mail, Telegram & more',
            color: AppTheme.primary,
            onTap: onShare,
          ),
          const SizedBox(height: 8),
          _SheetAction(
            icon: 'cloud_upload',
            label: 'Export to cloud storage',
            subtitle: kIsWeb
                ? 'File was downloaded to your browser'
                : 'File saved in Music/SoundBoost folder',
            color: const Color(0xFF0EA5E9),
            onTap: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    kIsWeb
                        ? '"${item.name}" was downloaded to your browser.'
                        : '"${item.name}" is in Music/SoundBoost. Open your Files app to upload to cloud.',
                  ),
                  backgroundColor: const Color(0xFF0EA5E9),
                  duration: const Duration(seconds: 4),
                ),
              );
            },
          ),
          const SizedBox(height: 8),
          _SheetAction(
            icon: 'delete_outline',
            label: 'Remove from library',
            subtitle: 'Removes from this list (file stays on device)',
            color: Colors.redAccent,
            onTap: onDelete,
          ),
        ],
      ),
    );
  }
}

class _SheetAction extends StatelessWidget {
  final String icon;
  final String label;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _SheetAction({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: color.withAlpha(15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withAlpha(50), width: 1.5),
        ),
        child: Row(
          children: [
            CustomIconWidget(iconName: icon, color: color, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: GoogleFonts.manrope(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            CustomIconWidget(
              iconName: 'chevron_right',
              color: theme.colorScheme.onSurfaceVariant,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
}
