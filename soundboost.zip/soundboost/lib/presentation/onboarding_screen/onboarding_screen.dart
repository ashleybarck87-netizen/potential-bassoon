import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  bool _micGranted = false;
  bool _audioGranted = false;
  bool _isRequestingMic = false;
  bool _isRequestingAudio = false;

  late AnimationController _pulseController;
  late AnimationController _fadeController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();

    _pulseAnimation = Tween<double>(begin: 0.92, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _fadeController, curve: Curves.easeOut));

    _checkExistingPermissions();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _checkExistingPermissions() async {
    final micStatus = await Permission.microphone.status;
    setState(() {
      _micGranted = micStatus.isGranted;
    });
    // Permission.audio is only available on Android 13+ (API 33+)
    if (!kIsWeb) {
      try {
        final audioStatus = await Permission.audio.status;
        setState(() {
          _audioGranted = audioStatus.isGranted || audioStatus.isLimited;
        });
      } catch (_) {
        // On older Android/iOS versions, audio permission may not exist
        setState(() => _audioGranted = true);
      }
    } else {
      setState(() => _audioGranted = true);
    }
  }

  Future<void> _requestMicPermission() async {
    setState(() => _isRequestingMic = true);
    HapticFeedback.lightImpact();
    if (kIsWeb) {
      // On web, permission_handler cannot request microphone access.
      // The browser will prompt when the mic is actually used (getUserMedia).
      // Grant it here so the user can proceed.
      setState(() {
        _micGranted = true;
        _isRequestingMic = false;
      });
      return;
    }
    final status = await Permission.microphone.request();
    setState(() {
      _micGranted = status.isGranted;
      _isRequestingMic = false;
    });
    if (status.isPermanentlyDenied) {
      _showSettingsDialog('Microphone');
    }
  }

  Future<void> _requestAudioPermission() async {
    setState(() => _isRequestingAudio = true);
    HapticFeedback.lightImpact();
    if (!kIsWeb) {
      try {
        final status = await Permission.audio.request();
        setState(() {
          _audioGranted = status.isGranted || status.isLimited;
          _isRequestingAudio = false;
        });
        if (status.isPermanentlyDenied) {
          _showSettingsDialog('Background Audio');
        }
      } catch (_) {
        setState(() {
          _audioGranted = true;
          _isRequestingAudio = false;
        });
      }
    } else {
      setState(() {
        _audioGranted = true;
        _isRequestingAudio = false;
      });
    }
  }

  void _showSettingsDialog(String permissionName) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surfaceLight,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
        ),
        title: Text(
          '$permissionName Permission Required',
          style: GoogleFonts.manrope(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: const Color(0xFF1A1A1A),
          ),
        ),
        content: Text(
          'Please enable $permissionName access in your device settings to use SoundBoost.',
          style: GoogleFonts.manrope(
            fontSize: 13,
            color: const Color(0xFF4A4A4A),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              'Cancel',
              style: GoogleFonts.manrope(
                color: const Color(0xFF4A4A4A),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              openAppSettings();
            },
            child: Text(
              'Open Settings',
              style: GoogleFonts.manrope(
                color: AppTheme.primary,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _continueToApp() {
    HapticFeedback.mediumImpact();
    Navigator.pushReplacementNamed(context, AppRoutes.mainScreen);
  }

  bool get _canContinue => _micGranted;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 2.h),
                _buildHeader(),
                SizedBox(height: 3.h),
                _buildIconSection(),
                SizedBox(height: 3.h),
                _buildPermissionCards(),
                const Spacer(),
                _buildContinueButton(),
                SizedBox(height: 2.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: AppTheme.primaryContainer,
            borderRadius: BorderRadius.circular(20.0),
          ),
          child: Text(
            'SoundBoost',
            style: GoogleFonts.manrope(
              fontSize: 11.sp,
              fontWeight: FontWeight.w700,
              color: AppTheme.primary,
              letterSpacing: 0.3,
            ),
          ),
        ),
        SizedBox(height: 1.5.h),
        Text(
          'Before we amplify,\nwe need access.',
          style: GoogleFonts.manrope(
            fontSize: 18.sp,
            fontWeight: FontWeight.w700,
            color: const Color(0xFF1A1A1A),
            height: 1.25,
            letterSpacing: -0.5,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'SoundBoost uses your microphone to capture and amplify sounds in real time. Background audio keeps it running when your screen is off.',
          style: GoogleFonts.manrope(
            fontSize: 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF4A4A4A),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildIconSection() {
    return Center(
      child: AnimatedBuilder(
        animation: _pulseAnimation,
        builder: (context, child) =>
            Transform.scale(scale: _pulseAnimation.value, child: child),
        child: Container(
          width: 22.w,
          height: 22.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [
                AppTheme.primaryLight.withAlpha(60),
                AppTheme.primaryContainer.withAlpha(40),
                AppTheme.backgroundLight,
              ],
              stops: const [0.3, 0.65, 1.0],
            ),
          ),
          child: Center(
            child: Container(
              width: 15.w,
              height: 15.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.primary,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primary.withAlpha(60),
                    blurRadius: 20,
                    spreadRadius: 4,
                  ),
                ],
              ),
              child: Icon(
                Icons.hearing_rounded,
                color: Colors.white,
                size: 7.w,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPermissionCards() {
    return Column(
      children: [
        _PermissionCard(
          icon: Icons.mic_rounded,
          title: 'Microphone Access',
          description: 'Required to capture and amplify sounds around you.',
          isGranted: _micGranted,
          isLoading: _isRequestingMic,
          isRequired: true,
          onTap: _micGranted ? null : _requestMicPermission,
        ),
        SizedBox(height: 1.5.h),
        _PermissionCard(
          icon: Icons.headphones_rounded,
          title: 'Background Audio',
          description: 'Keeps amplification active when the screen is off.',
          isGranted: _audioGranted,
          isLoading: _isRequestingAudio,
          isRequired: false,
          onTap: _audioGranted ? null : _requestAudioPermission,
        ),
      ],
    );
  }

  Widget _buildContinueButton() {
    return Column(
      children: [
        if (!_micGranted)
          Padding(
            padding: EdgeInsets.only(bottom: 1.5.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.info_outline_rounded,
                  size: 14,
                  color: AppTheme.warning,
                ),
                const SizedBox(width: 6),
                Text(
                  'Microphone permission is required to continue',
                  style: GoogleFonts.manrope(
                    fontSize: 10.sp,
                    color: AppTheme.warning,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        SizedBox(
          width: double.infinity,
          height: 6.5.h,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14.0),
              gradient: _canContinue
                  ? LinearGradient(
                      colors: [AppTheme.primary, AppTheme.secondary],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    )
                  : null,
              color: _canContinue ? null : AppTheme.outlineLight,
            ),
            child: ElevatedButton(
              onPressed: _canContinue ? _continueToApp : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                disabledBackgroundColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14.0),
                ),
              ),
              child: Text(
                'Enable Amplification',
                style: GoogleFonts.manrope(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w700,
                  color: _canContinue ? Colors.white : const Color(0xFFAAAAAA),
                  letterSpacing: 0.2,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _PermissionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final bool isGranted;
  final bool isLoading;
  final bool isRequired;
  final VoidCallback? onTap;

  const _PermissionCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.isGranted,
    required this.isLoading,
    required this.isRequired,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOut,
      decoration: BoxDecoration(
        color: isGranted
            ? AppTheme.primaryContainer.withAlpha(80)
            : AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: isGranted ? AppTheme.primaryLight : AppTheme.outlineLight,
          width: isGranted ? 1.5 : 1.0,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: isGranted
                    ? AppTheme.primary
                    : AppTheme.surfaceVariantLight,
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Icon(
                isGranted ? Icons.check_rounded : icon,
                color: isGranted ? Colors.white : AppTheme.primary,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        title,
                        style: GoogleFonts.manrope(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF1A1A1A),
                        ),
                      ),
                      if (isRequired) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.primary.withAlpha(20),
                            borderRadius: BorderRadius.circular(6.0),
                          ),
                          child: Text(
                            'Required',
                            style: GoogleFonts.manrope(
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.primary,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    description,
                    style: GoogleFonts.manrope(
                      fontSize: 11,
                      color: const Color(0xFF4A4A4A),
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            if (!isGranted)
              isLoading
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppTheme.primary,
                      ),
                    )
                  : GestureDetector(
                      onTap: onTap,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 7,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.primary,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Text(
                          'Allow',
                          style: GoogleFonts.manrope(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
          ],
        ),
      ),
    );
  }
}
