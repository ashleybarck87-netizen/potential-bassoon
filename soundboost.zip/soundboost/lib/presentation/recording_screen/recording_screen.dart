import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/app_export.dart';
import '../../services/audio_pipeline_service.dart';
import '../recordings_library_screen/recordings_library_screen.dart';

import '../main_screen/widgets/noise_reduction_export_web.dart'
    if (dart.library.io) '../main_screen/widgets/noise_reduction_export_io.dart';

class RecordingScreen extends StatefulWidget {
  const RecordingScreen({super.key});

  @override
  State<RecordingScreen> createState() => _RecordingScreenState();
}

class _RecordingScreenState extends State<RecordingScreen>
    with TickerProviderStateMixin {
  final AudioPipelineService _pipeline = AudioPipelineService();
  final TextEditingController _nameController = TextEditingController();

  bool _isRecording = false;
  bool _isSaving = false;
  bool _isPipelineRunning = false;
  int _elapsedSeconds = 0;
  Timer? _timer;
  String _selectedFormat = 'WAV';
  String? _lastSavedPath;

  // Waveform animation
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  // Recording history (in-session)
  final List<_RecordingEntry> _recordings = [];

  @override
  void initState() {
    super.initState();
    _nameController.text = _defaultName();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseController.dispose();
    _nameController.dispose();
    if (_isPipelineRunning) {
      _pipeline.stopPipeline();
    }
    super.dispose();
  }

  String _defaultName() {
    final now = DateTime.now();
    return 'Recording_${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
  }

  String _formatDuration(int seconds) {
    final h = (seconds ~/ 3600).toString().padLeft(2, '0');
    final m = ((seconds % 3600) ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return seconds >= 3600 ? '$h:$m:$s' : '$m:$s';
  }

  Future<void> _startRecording() async {
    HapticFeedback.mediumImpact();
    final started = await _pipeline.startPipeline();
    if (!started) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Microphone permission required to start recording.'),
            duration: Duration(seconds: 2),
          ),
        );
      }
      return;
    }
    _pipeline.startExportCapture();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _elapsedSeconds++);
    });
    setState(() {
      _isRecording = true;
      _isPipelineRunning = true;
      _elapsedSeconds = 0;
      _lastSavedPath = null;
    });
  }

  Future<void> _stopRecording() async {
    HapticFeedback.mediumImpact();
    _timer?.cancel();
    setState(() {
      _isRecording = false;
      _isSaving = true;
    });

    final Uint8List? wavBytes = _pipeline.stopExportCapture();
    await _pipeline.stopPipeline();
    setState(() => _isPipelineRunning = false);

    if (wavBytes == null || wavBytes.isEmpty) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No audio captured. Try recording for longer.'),
            duration: Duration(seconds: 2),
          ),
        );
      }
      return;
    }

    final customName = _nameController.text.trim().isEmpty
        ? _defaultName()
        : _nameController.text.trim();
    final ext = _selectedFormat.toLowerCase();
    final fileName = '$customName.$ext';

    // For MP3 we still save as WAV bytes (no encoder available client-side),
    // but rename with .mp3 extension so the user gets their chosen name.
    // A proper MP3 encoder can be plugged in here when available.
    final bytesToSave = wavBytes;

    try {
      await saveWavFile(bytesToSave, fileName);
      setState(() {
        _lastSavedPath = fileName;
        _isSaving = false;
        final entry = _RecordingEntry(
          name: fileName,
          duration: _elapsedSeconds,
          format: _selectedFormat,
          savedAt: DateTime.now(),
        );
        _recordings.insert(0, entry);
        // Also push to global store for the library screen
        RecordingsStore.instance.add(
          RecordingItem(
            name: fileName,
            durationSeconds: _elapsedSeconds,
            format: _selectedFormat,
            savedAt: DateTime.now(),
            filePath: kIsWeb ? null : fileName,
          ),
        );
        _nameController.text = _defaultName();
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              kIsWeb ? 'Download started: $fileName' : 'Saved: $fileName',
            ),
            backgroundColor: AppTheme.primary,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Save failed: $e'),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  void _discardRecording() {
    HapticFeedback.lightImpact();
    _timer?.cancel();
    _pipeline.stopExportCapture();
    if (_isPipelineRunning) {
      _pipeline.stopPipeline();
    }
    setState(() {
      _isRecording = false;
      _isSaving = false;
      _isPipelineRunning = false;
      _elapsedSeconds = 0;
      _nameController.text = _defaultName();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context, theme),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 8,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 8),
                    _buildRecordCard(theme),
                    const SizedBox(height: 20),
                    _buildSettingsCard(theme),
                    const SizedBox(height: 20),
                    if (_recordings.isNotEmpty) ...[
                      _buildHistorySection(theme),
                      const SizedBox(height: 24),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context, ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline,
                  width: 1.5,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'arrow_back',
                color: theme.colorScheme.onSurface,
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Recording Studio',
                style: GoogleFonts.manrope(
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.onSurface,
                  letterSpacing: -0.4,
                ),
              ),
              Text(
                'Capture processed audio output',
                style: GoogleFonts.manrope(
                  fontSize: 11,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRecordCard(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _isRecording
              ? Colors.redAccent.withAlpha(160)
              : theme.colorScheme.outline,
          width: 1.5,
        ),
      ),
      child: Column(
        children: [
          // Timer display
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (context, child) {
              return Transform.scale(
                scale: _isRecording ? _pulseAnim.value : 1.0,
                child: child,
              );
            },
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _isRecording
                    ? Colors.redAccent.withAlpha(20)
                    : AppTheme.primary.withAlpha(20),
                border: Border.all(
                  color: _isRecording
                      ? Colors.redAccent.withAlpha(120)
                      : AppTheme.primary.withAlpha(80),
                  width: 2,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_isRecording)
                    Container(
                      width: 10,
                      height: 10,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.redAccent,
                      ),
                    ),
                  if (_isRecording) const SizedBox(height: 6),
                  Text(
                    _formatDuration(_elapsedSeconds),
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: _isRecording ? 22 : 26,
                      fontWeight: FontWeight.w700,
                      color: _isRecording
                          ? Colors.redAccent
                          : theme.colorScheme.onSurface,
                      letterSpacing: 1.5,
                    ),
                  ),
                  Text(
                    _isRecording ? 'Recording' : 'Ready',
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: _isRecording
                          ? Colors.redAccent.withAlpha(180)
                          : theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          // Pipeline status
          if (!_isRecording && !_isSaving)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.primary.withAlpha(15),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: AppTheme.primary.withAlpha(60),
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(
                    iconName: 'info_outline',
                    color: AppTheme.primary,
                    size: 13,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Pipeline starts automatically on record',
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.primary,
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 20),
          // Action buttons
          if (_isSaving)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppTheme.primary,
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'Saving $_selectedFormat file…',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            )
          else if (_isRecording)
            Row(
              children: [
                Expanded(
                  child: _ActionButton(
                    label: 'Discard',
                    icon: 'delete_outline',
                    color: theme.colorScheme.onSurfaceVariant,
                    backgroundColor: theme.colorScheme.surfaceContainerHighest,
                    onTap: _discardRecording,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: _ActionButton(
                    label: 'Stop & Save',
                    icon: 'stop_circle',
                    color: Colors.white,
                    backgroundColor: Colors.redAccent,
                    onTap: _stopRecording,
                  ),
                ),
              ],
            )
          else
            SizedBox(
              width: double.infinity,
              child: _ActionButton(
                label: 'Start Recording',
                icon: 'fiber_manual_record',
                color: Colors.white,
                backgroundColor: AppTheme.primary,
                onTap: _startRecording,
                large: true,
              ),
            ),
          if (_lastSavedPath != null && !kIsWeb) ...[
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: 'check_circle',
                  color: AppTheme.success,
                  size: 14,
                ),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    _lastSavedPath!.split('/').last,
                    style: GoogleFonts.manrope(
                      fontSize: 11,
                      color: AppTheme.success,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSettingsCard(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.outline, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: AppTheme.primary.withAlpha(20),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const CustomIconWidget(
                  iconName: 'tune',
                  color: AppTheme.primary,
                  size: 16,
                ),
              ),
              const SizedBox(width: 10),
              Text('Export Settings', style: theme.textTheme.titleSmall),
            ],
          ),
          const SizedBox(height: 16),
          // File name field
          Text(
            'FILE NAME',
            style: GoogleFonts.manrope(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurfaceVariant,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _nameController,
            enabled: !_isRecording,
            style: GoogleFonts.jetBrainsMono(
              fontSize: 13,
              color: theme.colorScheme.onSurface,
            ),
            decoration: InputDecoration(
              hintText: 'Enter custom file name…',
              hintStyle: GoogleFonts.manrope(
                fontSize: 13,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              filled: true,
              fillColor: theme.colorScheme.surfaceContainerHighest,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 10,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
              suffixIcon: Padding(
                padding: const EdgeInsets.only(right: 8),
                child: CustomIconWidget(
                  iconName: 'edit',
                  color: theme.colorScheme.onSurfaceVariant,
                  size: 16,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Format selector
          Text(
            'OUTPUT FORMAT',
            style: GoogleFonts.manrope(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurfaceVariant,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: ['WAV', 'MP3'].map((fmt) {
              final selected = _selectedFormat == fmt;
              return Expanded(
                child: GestureDetector(
                  onTap: _isRecording
                      ? null
                      : () {
                          HapticFeedback.selectionClick();
                          setState(() => _selectedFormat = fmt);
                        },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    margin: EdgeInsets.only(right: fmt == 'WAV' ? 8 : 0),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: selected
                          ? AppTheme.primary
                          : theme.colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: selected
                            ? AppTheme.primary
                            : theme.colorScheme.outline,
                        width: 1.5,
                      ),
                    ),
                    child: Column(
                      children: [
                        CustomIconWidget(
                          iconName: fmt == 'WAV' ? 'audio_file' : 'music_note',
                          color: selected
                              ? Colors.white
                              : theme.colorScheme.onSurfaceVariant,
                          size: 20,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          fmt,
                          style: GoogleFonts.manrope(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: selected
                                ? Colors.white
                                : theme.colorScheme.onSurface,
                          ),
                        ),
                        Text(
                          fmt == 'WAV'
                              ? 'Lossless · 16-bit'
                              : 'Compressed · ~128kbps',
                          style: GoogleFonts.manrope(
                            fontSize: 9,
                            color: selected
                                ? Colors.white.withAlpha(180)
                                : theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          // Info note
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppTheme.warning.withAlpha(15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.warning.withAlpha(60),
                width: 1,
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomIconWidget(
                  iconName: 'info_outline',
                  color: AppTheme.warning,
                  size: 14,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _selectedFormat == 'WAV'
                        ? 'WAV files are saved as 16-bit PCM at 16 kHz — full fidelity, no compression.'
                        : 'MP3 export saves processed audio with .mp3 extension. Audio is captured at 16-bit PCM quality.',
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      color: AppTheme.warning,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistorySection(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'THIS SESSION',
              style: GoogleFonts.manrope(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurfaceVariant,
                letterSpacing: 0.8,
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: () => Navigator.pushNamed(
                context,
                AppRoutes.recordingsLibraryScreen,
              ),
              child: Row(
                children: [
                  Text(
                    'View Library',
                    style: GoogleFonts.manrope(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.primary,
                    ),
                  ),
                  const SizedBox(width: 2),
                  const CustomIconWidget(
                    iconName: 'chevron_right',
                    color: AppTheme.primary,
                    size: 14,
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        ..._recordings.map(
          (r) => _RecordingTile(
            recording: r,
            theme: theme,
            onShare: () => _shareEntry(r),
            onMore: () => _showEntryOptions(r),
          ),
        ),
      ],
    );
  }

  Future<void> _shareEntry(_RecordingEntry r) async {
    HapticFeedback.lightImpact();
    if (kIsWeb) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'On web, use the download button to save "${r.name}" then share from your device.',
          ),
          backgroundColor: AppTheme.primary,
          duration: const Duration(seconds: 3),
        ),
      );
      return;
    }
    try {
      await Share.shareXFiles(
        [
          XFile(
            r.name,
            mimeType: r.format == 'WAV' ? 'audio/wav' : 'audio/mpeg',
          ),
        ],
        subject: r.name,
        text: 'Processed audio from SoundBoost: ${r.name}',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Share failed: $e'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  void _showEntryOptions(_RecordingEntry r) {
    HapticFeedback.lightImpact();
    final theme = Theme.of(context);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: theme.colorScheme.outline, width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              r.name,
              style: GoogleFonts.manrope(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              '${r.format} · ${_formatDuration(r.duration)}',
              style: GoogleFonts.manrope(
                fontSize: 11,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: () {
                Navigator.pop(ctx);
                _shareEntry(r);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withAlpha(15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.primary.withAlpha(50),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  children: [
                    const CustomIconWidget(
                      iconName: 'share',
                      color: AppTheme.primary,
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Share via messaging / email',
                            style: GoogleFonts.manrope(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: theme.colorScheme.onSurface,
                            ),
                          ),
                          Text(
                            'Send to WhatsApp, Mail, Telegram & more',
                            style: GoogleFonts.manrope(
                              fontSize: 10,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      kIsWeb
                          ? '"${r.name}" was downloaded to your browser.'
                          : '"${r.name}" is in Music/SoundBoost. Open your Files app to upload to cloud.',
                    ),
                    backgroundColor: const Color(0xFF0EA5E9),
                    duration: const Duration(seconds: 4),
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF0EA5E9).withAlpha(15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: const Color(0xFF0EA5E9).withAlpha(50),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  children: [
                    const CustomIconWidget(
                      iconName: 'cloud_upload',
                      color: Color(0xFF0EA5E9),
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Export to cloud storage',
                            style: GoogleFonts.manrope(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: theme.colorScheme.onSurface,
                            ),
                          ),
                          Text(
                            kIsWeb
                                ? 'File was downloaded to your browser'
                                : 'File saved in Music/SoundBoost folder',
                            style: GoogleFonts.manrope(
                              fontSize: 10,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Supporting widgets ────────────────────────────────────────────────────────

class _ActionButton extends StatelessWidget {
  final String label;
  final String icon;
  final Color color;
  final Color backgroundColor;
  final VoidCallback onTap;
  final bool large;

  const _ActionButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.backgroundColor,
    required this.onTap,
    this.large = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: large ? 16 : 12,
          horizontal: 16,
        ),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(iconName: icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: GoogleFonts.manrope(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RecordingEntry {
  final String name;
  final int duration;
  final String format;
  final DateTime savedAt;

  const _RecordingEntry({
    required this.name,
    required this.duration,
    required this.format,
    required this.savedAt,
  });
}

class _RecordingTile extends StatelessWidget {
  final _RecordingEntry recording;
  final ThemeData theme;
  final VoidCallback onShare;
  final VoidCallback onMore;

  const _RecordingTile({
    required this.recording,
    required this.theme,
    required this.onShare,
    required this.onMore,
  });

  String _fmt(int s) {
    final m = (s ~/ 60).toString().padLeft(2, '0');
    final sec = (s % 60).toString().padLeft(2, '0');
    return '$m:$sec';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.colorScheme.outline, width: 1.5),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppTheme.primary.withAlpha(20),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const CustomIconWidget(
              iconName: 'audio_file',
              color: AppTheme.primary,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  recording.name,
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  '${_fmt(recording.duration)} · ${recording.format}',
                  style: GoogleFonts.manrope(
                    fontSize: 10,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: AppTheme.success.withAlpha(20),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              'Saved',
              style: GoogleFonts.manrope(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                color: AppTheme.success,
              ),
            ),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: onShare,
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: AppTheme.primary.withAlpha(20),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const CustomIconWidget(
                iconName: 'share',
                color: AppTheme.primary,
                size: 15,
              ),
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: onMore,
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: 'more_vert',
                color: theme.colorScheme.onSurfaceVariant,
                size: 15,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
