import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class SettingsToggleSectionWidget extends StatelessWidget {
  final bool backgroundMode;
  final bool autoGainControl;
  final bool monoOutput;
  final bool hapticFeedback;
  final ValueChanged<bool> onBackgroundModeChanged;
  final ValueChanged<bool> onAutoGainChanged;
  final ValueChanged<bool> onMonoOutputChanged;
  final ValueChanged<bool> onHapticFeedbackChanged;

  const SettingsToggleSectionWidget({
    super.key,
    required this.backgroundMode,
    required this.autoGainControl,
    required this.monoOutput,
    required this.hapticFeedback,
    required this.onBackgroundModeChanged,
    required this.onAutoGainChanged,
    required this.onMonoOutputChanged,
    required this.onHapticFeedbackChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.outline, width: 1.5),
      ),
      child: Column(
        children: [
          _ToggleRow(
            iconName: 'power_settings_new',
            title: 'Background Mode',
            subtitle: 'Keep running when screen turns off',
            value: backgroundMode,
            onChanged: (v) {
              HapticFeedback.selectionClick();
              onBackgroundModeChanged(v);
            },
            isFirst: true,
            isLast: false,
          ),
          _Divider(),
          _ToggleRow(
            iconName: 'graphic_eq',
            title: 'Auto Gain Control',
            subtitle: 'Automatically adjust for loud sounds',
            value: autoGainControl,
            onChanged: (v) {
              HapticFeedback.selectionClick();
              onAutoGainChanged(v);
            },
            isFirst: false,
            isLast: false,
          ),
          _Divider(),
          _ToggleRow(
            iconName: 'headphones',
            title: 'Mono Output',
            subtitle: 'Combine channels for single earpiece',
            value: monoOutput,
            onChanged: (v) {
              HapticFeedback.selectionClick();
              onMonoOutputChanged(v);
            },
            isFirst: false,
            isLast: false,
          ),
          _Divider(),
          _ToggleRow(
            iconName: 'notifications',
            title: 'Haptic Feedback',
            subtitle: 'Vibrate on control changes',
            value: hapticFeedback,
            onChanged: (v) {
              onHapticFeedbackChanged(v);
            },
            isFirst: false,
            isLast: true,
          ),
        ],
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Divider(
        height: 1,
        thickness: 1,
        color: Theme.of(context).colorScheme.outlineVariant,
      ),
    );
  }
}

class _ToggleRow extends StatelessWidget {
  final String iconName;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  final bool isFirst;
  final bool isLast;

  const _ToggleRow({
    required this.iconName,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
    required this.isFirst,
    required this.isLast,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: value
                  ? AppTheme.primary.withAlpha(26)
                  : theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(9),
            ),
            child: CustomIconWidget(
              iconName: iconName,
              color: value
                  ? AppTheme.primary
                  : theme.colorScheme.onSurfaceVariant,
              size: 17,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: theme.textTheme.titleSmall),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
        ],
      ),
    );
  }
}
