import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class EQBandSlidersWidget extends StatelessWidget {
  final List<double> bands;
  final void Function(int index, double value) onBandChanged;

  const EQBandSlidersWidget({
    super.key,
    required this.bands,
    required this.onBandChanged,
  });

  static const List<String> _bandLabels = [
    '60\nHz',
    '250\nHz',
    '1\nkHz',
    '4\nkHz',
    '12\nkHz',
  ];

  static const List<String> _bandShortLabels = [
    '60Hz',
    '250Hz',
    '1kHz',
    '4kHz',
    '12kHz',
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.outline, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Frequency Equalizer', style: theme.textTheme.titleSmall),
              GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  // TODO: Reset EQ to flat
                  for (int i = 0; i < bands.length; i++) {
                    onBandChanged(i, 0.0);
                  }
                },
                child: Text(
                  'Reset',
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Boost or cut specific frequency ranges',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 20),
          // dB scale labels + sliders
          SizedBox(
            height: 200,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Y-axis labels
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: ['+12', '+6', '0', '-6', '-12']
                      .map(
                        (l) => Text(
                          l,
                          style: GoogleFonts.manrope(
                            fontSize: 9,
                            fontWeight: FontWeight.w500,
                            color: theme.colorScheme.onSurfaceVariant,
                            fontFeatures: [const FontFeature.tabularFigures()],
                          ),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(width: 8),
                // Zero line reference
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 0),
                  child: Column(
                    children: [
                      const Spacer(),
                      Container(width: 1, height: 1, color: Colors.transparent),
                      const Spacer(),
                    ],
                  ),
                ),
                // Band sliders
                Expanded(
                  child: Stack(
                    children: [
                      // Center line
                      Positioned(
                        top: 0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Center(
                          child: Container(
                            height: 1,
                            color: theme.colorScheme.outlineVariant,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: List.generate(bands.length, (i) {
                          return _EQBandSlider(
                            value: bands[i],
                            label: _bandShortLabels[i],
                            onChanged: (v) => onBandChanged(i, v),
                          );
                        }),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Band labels row
          Padding(
            padding: const EdgeInsets.only(left: 24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: _bandShortLabels
                  .map(
                    (l) => Text(
                      l,
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _EQBandSlider extends StatelessWidget {
  final double value;
  final String label;
  final ValueChanged<double> onChanged;

  const _EQBandSlider({
    required this.value,
    required this.label,
    required this.onChanged,
  });

  Color _bandColor(double v) {
    if (v > 0) return AppTheme.primary;
    if (v < 0) return AppTheme.warning;
    return const Color(0xFF9E9E9E);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bandColor = _bandColor(value);

    return Column(
      children: [
        // dB value label
        Text(
          '${value >= 0 ? '+' : ''}${value.toStringAsFixed(0)}',
          style: GoogleFonts.manrope(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: bandColor,
            fontFeatures: [const FontFeature.tabularFigures()],
          ),
        ),
        const SizedBox(height: 4),
        Expanded(
          child: RotatedBox(
            quarterTurns: 3,
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: bandColor,
                inactiveTrackColor: theme.colorScheme.outlineVariant,
                thumbColor: bandColor,
                overlayColor: bandColor.withAlpha(31),
                trackHeight: 3,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
              ),
              child: Slider(
                value: value,
                min: -12,
                max: 12,
                divisions: 24,
                onChanged: (v) {
                  HapticFeedback.selectionClick();
                  onChanged(v);
                },
              ),
            ),
          ),
        ),
      ],
    );
  }
}
