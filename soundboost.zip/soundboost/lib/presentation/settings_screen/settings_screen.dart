import 'package:flutter/services.dart';

import '../../core/app_export.dart';
import '../../services/supabase_service.dart';
import './widgets/eq_band_sliders_widget.dart';
import './widgets/preset_management_widget.dart';
import './widgets/settings_toggle_section_widget.dart';

// TODO: Replace with Riverpod/Bloc for production settings persistence

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // TODO: Persist with shared_preferences
  bool _backgroundMode = false;
  bool _autoGainControl = true;
  bool _monoOutput = false;
  bool _hapticFeedback = true;

  // EQ bands: 60Hz, 250Hz, 1kHz, 4kHz, 12kHz
  // Values in dB, range -12 to +12
  final List<double> _eqBands = [2.0, 4.0, 0.0, 3.0, -2.0];

  bool _presetsLoading = true;
  String? _presetsError;

  static const List<Map<String, dynamic>> _defaultPresets = [
    {
      'id': 'p1',
      'name': 'Voice',
      'description': 'Optimized for speech clarity',
      'iconName': 'record_voice_over',
      'gainDb': 18.0,
      'noiseReduction': 75.0,
      'eqBands': [0.0, 0.0, 0.0, 0.0, 0.0],
      'isBuiltIn': true,
    },
    {
      'id': 'p2',
      'name': 'Nature',
      'description': 'Bird calls and wildlife sounds',
      'iconName': 'forest',
      'gainDb': 12.0,
      'noiseReduction': 60.0,
      'eqBands': [0.0, 0.0, 0.0, 0.0, 0.0],
      'isBuiltIn': true,
    },
    {
      'id': 'p3',
      'name': 'Hunt',
      'description': 'Max sensitivity, wind blocked',
      'iconName': 'hearing',
      'gainDb': 22.0,
      'noiseReduction': 80.0,
      'eqBands': [0.0, 0.0, 0.0, 0.0, 0.0],
      'isBuiltIn': true,
    },
    {
      'id': 'p4',
      'name': 'Music',
      'description': 'Balanced frequency response',
      'iconName': 'music_note',
      'gainDb': 8.0,
      'noiseReduction': 40.0,
      'eqBands': [0.0, 0.0, 0.0, 0.0, 0.0],
      'isBuiltIn': true,
    },
    {
      'id': 'p5',
      'name': 'Custom',
      'description': 'Your personal configuration',
      'iconName': 'tune',
      'gainDb': 15.0,
      'noiseReduction': 55.0,
      'eqBands': [0.0, 0.0, 0.0, 0.0, 0.0],
      'isBuiltIn': false,
    },
  ];

  List<Map<String, dynamic>> _presetMaps = List<Map<String, dynamic>>.from(
    _defaultPresets.map((p) => Map<String, dynamic>.from(p)),
  );

  @override
  void initState() {
    super.initState();
    _loadPresets();
  }

  Future<void> _loadPresets() async {
    setState(() {
      _presetsLoading = true;
      _presetsError = null;
    });
    try {
      final rows = await SupabaseService.instance.fetchPresets();
      if (rows != null && rows.isNotEmpty) {
        // Merge remote presets with defaults (remote wins for matching keys)
        final remoteMap = {
          for (final r in rows)
            r['preset_key'] as String: SupabaseService.rowToPresetMap(r),
        };
        final merged = _defaultPresets.map((def) {
          final key = def['id'] as String;
          return remoteMap.containsKey(key)
              ? remoteMap[key]!
              : Map<String, dynamic>.from(def);
        }).toList();
        setState(() {
          _presetMaps = merged;
          _presetsLoading = false;
        });
      } else {
        // No remote presets yet — push defaults to Supabase
        await SupabaseService.instance.upsertPresets(
          _defaultPresets.map((p) => Map<String, dynamic>.from(p)).toList(),
        );
        setState(() => _presetsLoading = false);
      }
    } catch (_) {
      setState(() {
        _presetsLoading = false;
        _presetsError = 'Could not sync presets';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isTablet = MediaQuery.of(context).size.width >= 600;
    final isLargeTablet = MediaQuery.of(context).size.width >= 840;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildFloatingAppBar(context, theme),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.symmetric(
                  horizontal: isTablet ? 32 : 20,
                  vertical: 8,
                ),
                child: isLargeTablet
                    ? _buildTabletLayout(context, theme)
                    : _buildPhoneLayout(context, theme),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhoneLayout(BuildContext context, ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        _sectionLabel(theme, 'Equalizer'),
        const SizedBox(height: 12),
        EQBandSlidersWidget(
          bands: _eqBands,
          onBandChanged: (index, value) =>
              setState(() => _eqBands[index] = value),
        ),
        const SizedBox(height: 24),
        _sectionLabel(theme, 'Audio Processing'),
        const SizedBox(height: 12),
        SettingsToggleSectionWidget(
          backgroundMode: _backgroundMode,
          autoGainControl: _autoGainControl,
          monoOutput: _monoOutput,
          hapticFeedback: _hapticFeedback,
          onBackgroundModeChanged: (v) => setState(() => _backgroundMode = v),
          onAutoGainChanged: (v) => setState(() => _autoGainControl = v),
          onMonoOutputChanged: (v) => setState(() => _monoOutput = v),
          onHapticFeedbackChanged: (v) => setState(() => _hapticFeedback = v),
        ),
        const SizedBox(height: 24),
        _buildPresetsSection(theme),
        const SizedBox(height: 32),
      ],
    );
  }

  Widget _buildTabletLayout(BuildContext context, ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionLabel(theme, 'Equalizer'),
                  const SizedBox(height: 12),
                  EQBandSlidersWidget(
                    bands: _eqBands,
                    onBandChanged: (index, value) =>
                        setState(() => _eqBands[index] = value),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 24),
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionLabel(theme, 'Audio Processing'),
                  const SizedBox(height: 12),
                  SettingsToggleSectionWidget(
                    backgroundMode: _backgroundMode,
                    autoGainControl: _autoGainControl,
                    monoOutput: _monoOutput,
                    hapticFeedback: _hapticFeedback,
                    onBackgroundModeChanged: (v) =>
                        setState(() => _backgroundMode = v),
                    onAutoGainChanged: (v) =>
                        setState(() => _autoGainControl = v),
                    onMonoOutputChanged: (v) => setState(() => _monoOutput = v),
                    onHapticFeedbackChanged: (v) =>
                        setState(() => _hapticFeedback = v),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        _buildPresetsSection(theme),
        const SizedBox(height: 32),
      ],
    );
  }

  Widget _buildPresetsSection(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: _sectionLabel(theme, 'Presets')),
            if (_presetsLoading)
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            else
              GestureDetector(
                onTap: _loadPresets,
                child: CustomIconWidget(
                  iconName: 'sync',
                  color: theme.colorScheme.onSurfaceVariant,
                  size: 18,
                ),
              ),
          ],
        ),
        if (_presetsError != null) ...[
          const SizedBox(height: 6),
          Text(
            _presetsError!,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.error,
            ),
          ),
        ],
        const SizedBox(height: 12),
        PresetManagementWidget(
          presetMaps: _presetMaps,
          onPresetEdit: _onEditPreset,
        ),
      ],
    );
  }

  Widget _sectionLabel(ThemeData theme, String label) {
    return Text(
      label.toUpperCase(),
      style: GoogleFonts.manrope(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: theme.colorScheme.onSurfaceVariant,
        letterSpacing: 1.2,
      ),
    );
  }

  void _onEditPreset(String presetId) {
    HapticFeedback.selectionClick();
    final preset = _presetMaps.firstWhere((p) => p['id'] == presetId);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _PresetEditSheet(
        preset: preset,
        onSaved: (updatedPreset) async {
          // Update local state
          setState(() {
            final idx = _presetMaps.indexWhere((p) => p['id'] == presetId);
            if (idx != -1) _presetMaps[idx] = updatedPreset;
          });
          // Sync to Supabase
          final eqBands =
              updatedPreset['eqBands'] as List<double>? ??
              [0.0, 0.0, 0.0, 0.0, 0.0];
          await SupabaseService.instance.upsertPreset(
            presetKey: updatedPreset['id'] as String,
            name: updatedPreset['name'] as String,
            description: updatedPreset['description'] as String,
            iconName: updatedPreset['iconName'] as String,
            gainDb: (updatedPreset['gainDb'] as num).toDouble(),
            noiseReduction: (updatedPreset['noiseReduction'] as num).toDouble(),
            eqBands: eqBands,
            isBuiltIn: updatedPreset['isBuiltIn'] as bool? ?? false,
          );
        },
      ),
    );
  }

  Widget _buildFloatingAppBar(BuildContext context, ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline,
                  width: 1.5,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'arrow_back',
                color: theme.colorScheme.onSurface,
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Text(
            'Settings',
            style: GoogleFonts.manrope(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: theme.colorScheme.onSurface,
              letterSpacing: -0.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetEditSheet extends StatefulWidget {
  final Map<String, dynamic> preset;
  final Future<void> Function(Map<String, dynamic> updatedPreset) onSaved;

  const _PresetEditSheet({required this.preset, required this.onSaved});

  @override
  State<_PresetEditSheet> createState() => _PresetEditSheetState();
}

class _PresetEditSheetState extends State<_PresetEditSheet> {
  late TextEditingController _nameController;
  late TextEditingController _descController;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(
      text: widget.preset['name'] as String,
    );
    _descController = TextEditingController(
      text: widget.preset['description'] as String,
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        top: 20,
        left: 20,
        right: 20,
      ),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: theme.colorScheme.outline, width: 1.5),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: theme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text('Edit Preset', style: theme.textTheme.headlineSmall),
          const SizedBox(height: 20),
          Text(
            'Name',
            style: theme.textTheme.labelMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _nameController,
            style: theme.textTheme.bodyLarge,
            decoration: InputDecoration(
              hintText: 'Preset name',
              hintStyle: TextStyle(color: theme.colorScheme.onSurfaceVariant),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Description',
            style: theme.textTheme.labelMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _descController,
            style: theme.textTheme.bodyLarge,
            decoration: InputDecoration(
              hintText: 'Short description',
              hintStyle: TextStyle(color: theme.colorScheme.onSurfaceVariant),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _saving
                  ? null
                  : () async {
                      setState(() => _saving = true);
                      final updated = Map<String, dynamic>.from(widget.preset);
                      updated['name'] = _nameController.text.trim().isEmpty
                          ? widget.preset['name']
                          : _nameController.text.trim();
                      updated['description'] = _descController.text.trim();
                      await widget.onSaved(updated);
                      if (mounted) Navigator.pop(context);
                    },
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.primary,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : Text(
                      'Save Preset',
                      style: GoogleFonts.manrope(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
