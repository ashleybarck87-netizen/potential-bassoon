import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

/// Saves [bytes] as a WAV file named [fileName] to a user-accessible location.
///
/// Android: /storage/emulated/0/Music/SoundBoost/ (visible in Files & Music apps)
/// iOS:     Documents/ (accessible via Files app → On My iPhone → soundboost)
Future<void> saveWavFile(Uint8List bytes, String fileName) async {
  if (Platform.isAndroid) {
    await _saveAndroid(bytes, fileName);
  } else {
    // iOS: save to app Documents (accessible via Files app)
    final docsDir = await getApplicationDocumentsDirectory();
    final saveDir = Directory('${docsDir.path}/SoundBoost');
    if (!await saveDir.exists()) {
      await saveDir.create(recursive: true);
    }
    final file = File('${saveDir.path}/$fileName');
    await file.writeAsBytes(bytes, flush: true);
  }
}

/// Android-specific save: writes to public Music/SoundBoost directory and
/// notifies MediaStore so the file is immediately visible in Files/Music apps.
Future<void> _saveAndroid(Uint8List bytes, String fileName) async {
  const channel = MethodChannel('com.flutter_template.app/media_store');

  // Derive the public storage root from getExternalStorageDirectory
  String? publicRoot;
  try {
    final ext = await getExternalStorageDirectory();
    if (ext != null) {
      final parts = ext.path.split('/');
      final androidIdx = parts.indexOf('Android');
      if (androidIdx > 0) {
        publicRoot = parts.sublist(0, androidIdx).join('/');
      }
    }
  } catch (_) {}

  // Fallback to /storage/emulated/0
  publicRoot ??= '/storage/emulated/0';

  final saveDir = Directory('$publicRoot/Music/SoundBoost');
  if (!await saveDir.exists()) {
    await saveDir.create(recursive: true);
  }

  final file = File('${saveDir.path}/$fileName');
  await file.writeAsBytes(bytes, flush: true);

  // Notify MediaStore so the file appears immediately in Files/Music apps
  try {
    await channel.invokeMethod('scanFile', {'path': file.path});
  } catch (_) {
    // Silently continue — file is still saved
  }
}
