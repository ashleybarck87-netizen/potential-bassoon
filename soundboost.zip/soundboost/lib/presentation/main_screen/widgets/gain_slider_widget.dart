import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class GainSliderWidget extends StatelessWidget {
  final double gainDb;
  final bool isActive;
  final ValueChanged<double> onGainChanged;

  const GainSliderWidget({
    super.key,
    required this.gainDb,
    required this.isActive,
    required this.onGainChanged,
  });

  String get _gainLabel {
    if (gainDb < 6) return 'Low';
    if (gainDb < 15) return 'Medium';
    if (gainDb < 22) return 'High';
    return 'Max';
  }

  Color _gainColor(double db) {
    if (db < 6) return const Color(0xFF9E9E9E);
    if (db < 15) return AppTheme.primary;
    if (db < 22) return AppTheme.warning;
    return AppTheme.error;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final gainColor = _gainColor(gainDb);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.outline, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: AppTheme.primary.withAlpha(26),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const CustomIconWidget(
                  iconName: 'volume_up',
                  color: AppTheme.primary,
                  size: 17,
                ),
              ),
              const SizedBox(width: 10),
              Text('Gain Control', style: theme.textTheme.titleSmall),
              const Spacer(),
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: gainColor.withAlpha(26),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  _gainLabel,
                  style: GoogleFonts.manrope(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: gainColor,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Large dB value
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '+${gainDb.toStringAsFixed(0)}',
                style: GoogleFonts.manrope(
                  fontSize: 44,
                  fontWeight: FontWeight.w800,
                  color: gainColor,
                  letterSpacing: -2,
                  fontFeatures: [const FontFeature.tabularFigures()],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(
                  ' dB',
                  style: GoogleFonts.manrope(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          // Slider
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: gainColor,
              thumbColor: gainColor,
              overlayColor: gainColor.withAlpha(31),
              trackHeight: 3,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
            ),
            child: Slider(
              value: gainDb,
              min: 0,
              max: 30,
              divisions: 30,
              onChanged: (v) {
                HapticFeedback.selectionClick();
                onGainChanged(v);
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '0 dB',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                '30 dB',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
