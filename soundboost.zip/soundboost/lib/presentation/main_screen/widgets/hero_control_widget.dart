
import '../../../core/app_export.dart';

class HeroControlWidget extends StatefulWidget {
  final bool isAmplifying;
  final double gainDb;
  final bool isBackgroundMode;
  final VoidCallback onToggle;

  const HeroControlWidget({
    super.key,
    required this.isAmplifying,
    required this.gainDb,
    required this.isBackgroundMode,
    required this.onToggle,
  });

  @override
  State<HeroControlWidget> createState() => _HeroControlWidgetState();
}

class _HeroControlWidgetState extends State<HeroControlWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );
    _pulseAnim = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    if (widget.isAmplifying) _pulseController.repeat(reverse: true);
  }

  @override
  void didUpdateWidget(HeroControlWidget old) {
    super.didUpdateWidget(old);
    if (widget.isAmplifying && !old.isAmplifying) {
      _pulseController.repeat(reverse: true);
    } else if (!widget.isAmplifying && old.isAmplifying) {
      _pulseController.stop();
      _pulseController.animateTo(
        0,
        duration: const Duration(milliseconds: 200),
      );
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: widget.isAmplifying
            ? AppTheme.primary.withAlpha(13)
            : theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: widget.isAmplifying
              ? AppTheme.primary.withAlpha(89)
              : theme.colorScheme.outline,
          width: 1.5,
        ),
      ),
      child: Column(
        children: [
          // Status row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              StatusBadgeWidget(
                status: widget.isAmplifying
                    ? BadgeStatus.active
                    : BadgeStatus.inactive,
              ),
              if (widget.isBackgroundMode)
                StatusBadgeWidget(
                  status: BadgeStatus.background,
                  customLabel: 'BG MODE',
                ),
            ],
          ),
          const SizedBox(height: 28),
          // Central toggle button
          GestureDetector(
            onTap: widget.onToggle,
            child: AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, child) => Transform.scale(
                scale: widget.isAmplifying ? _pulseAnim.value : 1.0,
                child: child,
              ),
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.isAmplifying
                      ? AppTheme.primary
                      : theme.colorScheme.surfaceContainerHighest,
                  border: Border.all(
                    color: widget.isAmplifying
                        ? AppTheme.primary
                        : theme.colorScheme.outline,
                    width: 2,
                  ),
                  boxShadow: widget.isAmplifying
                      ? [
                          BoxShadow(
                            color: AppTheme.primary.withAlpha(64),
                            blurRadius: 24,
                            spreadRadius: 4,
                          ),
                        ]
                      : [],
                ),
                child: CustomIconWidget(
                  iconName: 'mic',
                  color: widget.isAmplifying
                      ? Colors.white
                      : theme.colorScheme.onSurfaceVariant,
                  size: 42,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          // State label
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 200),
            child: Text(
              widget.isAmplifying ? 'Amplifying' : 'Tap to Start',
              key: ValueKey(widget.isAmplifying),
              style: GoogleFonts.manrope(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: widget.isAmplifying
                    ? AppTheme.primary
                    : theme.colorScheme.onSurfaceVariant,
                letterSpacing: -0.3,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            widget.isAmplifying
                ? '+${widget.gainDb.toStringAsFixed(0)} dB gain'
                : 'Microphone ready',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
