import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../services/audio_pipeline_service.dart';
import '../../../services/supabase_service.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show FileOptions;

// Web-only download helper (kept for web fallback)
import 'noise_reduction_export_web.dart'
    if (dart.library.io) 'noise_reduction_export_io.dart';

/// Widget that controls noise-reduced audio recording and saves to Supabase storage.
class NoiseReductionExportWidget extends StatefulWidget {
  final bool isAmplifying;

  const NoiseReductionExportWidget({super.key, required this.isAmplifying});

  @override
  State<NoiseReductionExportWidget> createState() =>
      _NoiseReductionExportWidgetState();
}

class _NoiseReductionExportWidgetState
    extends State<NoiseReductionExportWidget> {
  final AudioPipelineService _pipeline = AudioPipelineService();
  bool _isCapturing = false;
  bool _isSaving = false;
  int _capturedSeconds = 0;
  Timer? _timer;
  String? _lastUploadedUrl;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startCapture() {
    HapticFeedback.mediumImpact();
    _pipeline.startExportCapture();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {
          _capturedSeconds = (_pipeline.capturedSampleCount / 16000).round();
        });
      }
    });
    setState(() {
      _isCapturing = true;
      _capturedSeconds = 0;
      _lastUploadedUrl = null;
    });
  }

  Future<void> _stopAndSave() async {
    HapticFeedback.mediumImpact();
    _timer?.cancel();
    setState(() {
      _isCapturing = false;
      _isSaving = true;
    });

    final Uint8List? wavBytes = _pipeline.stopExportCapture();
    if (wavBytes == null || wavBytes.isEmpty) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No audio captured yet. Start amplifying first.'),
            duration: Duration(seconds: 2),
          ),
        );
      }
      return;
    }

    final fileName =
        'soundboost_clean_${DateTime.now().millisecondsSinceEpoch}.wav';

    // Try Supabase storage first; fall back to local/web download on error
    if (!kIsWeb) {
      try {
        final url = await _uploadToSupabase(wavBytes, fileName);
        setState(() {
          _isSaving = false;
          _lastUploadedUrl = url;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Saved to cloud: $fileName'),
              duration: const Duration(seconds: 4),
              backgroundColor: AppTheme.primary,
            ),
          );
        }
        return;
      } catch (e) {
        debugPrint('Supabase upload failed, falling back to local: $e');
      }
    }

    // Web or Supabase fallback: local/browser download
    try {
      await saveWavFile(wavBytes, fileName);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              kIsWeb
                  ? 'Download started: $fileName'
                  : 'Saved to Music/SoundBoost:\n$fileName',
            ),
            duration: const Duration(seconds: 4),
            backgroundColor: AppTheme.primary,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Save failed: $e'),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }

    setState(() => _isSaving = false);
  }

  /// Upload WAV bytes to Supabase storage bucket 'recordings'.
  Future<String> _uploadToSupabase(Uint8List bytes, String fileName) async {
    final client = SupabaseService.instance.client;
    final filePath = 'recordings/$fileName';

    await client.storage
        .from('recordings')
        .uploadBinary(
          filePath,
          bytes,
          fileOptions: const FileOptions(
            contentType: 'audio/wav',
            upsert: false,
          ),
        );

    final publicUrl = client.storage.from('recordings').getPublicUrl(filePath);
    return publicUrl;
  }

  String _formatDuration(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final canCapture = widget.isAmplifying;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _isCapturing
              ? Colors.redAccent.withAlpha(140)
              : theme.colorScheme.outline,
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: _isCapturing
                      ? Colors.redAccent.withAlpha(30)
                      : AppTheme.primary.withAlpha(26),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: _isCapturing
                      ? 'fiber_manual_record'
                      : 'cloud_upload',
                  color: _isCapturing ? Colors.redAccent : AppTheme.primary,
                  size: 17,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Save Clean Audio',
                      style: theme.textTheme.titleSmall,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      kIsWeb
                          ? 'Noise-reduced WAV download'
                          : 'Saved to cloud storage',
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              // Noise floor status badge
              if (_pipeline.noiseFloorEstimated)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.green.withAlpha(30),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: Colors.green.withAlpha(100),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    'Calibrated',
                    style: GoogleFonts.manrope(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      color: Colors.green,
                    ),
                  ),
                )
              else
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.orange.withAlpha(30),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: Colors.orange.withAlpha(100),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    'Calibrating…',
                    style: GoogleFonts.manrope(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      color: Colors.orange,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          // Timer display when capturing
          if (_isCapturing) ...[
            Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Colors.redAccent,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'REC  ${_formatDuration(_capturedSeconds)}',
                    style: GoogleFonts.manrope(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: Colors.redAccent,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
          ],
          // Last uploaded URL indicator
          if (_lastUploadedUrl != null && !_isCapturing) ...[
            Row(
              children: [
                const CustomIconWidget(
                  iconName: 'check_circle',
                  color: Colors.green,
                  size: 14,
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Uploaded to cloud successfully',
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      color: Colors.green,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
          // Action buttons
          Row(
            children: [
              Expanded(
                child: _isCapturing
                    ? _buildStopButton()
                    : _buildStartButton(canCapture),
              ),
            ],
          ),
          if (!canCapture && !_isCapturing) ...[
            const SizedBox(height: 8),
            Text(
              'Start amplification to enable recording',
              style: GoogleFonts.manrope(
                fontSize: 10,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStartButton(bool enabled) {
    return GestureDetector(
      onTap: enabled ? _startCapture : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: enabled ? AppTheme.primary : AppTheme.primary.withAlpha(60),
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CustomIconWidget(
              iconName: 'fiber_manual_record',
              color: Colors.white,
              size: 14,
            ),
            const SizedBox(width: 6),
            Text(
              'Record Clean Audio',
              style: GoogleFonts.manrope(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStopButton() {
    return GestureDetector(
      onTap: _isSaving ? null : _stopAndSave,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: _isSaving ? Colors.grey : Colors.redAccent,
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _isSaving
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                : const CustomIconWidget(
                    iconName: 'stop',
                    color: Colors.white,
                    size: 14,
                  ),
            const SizedBox(width: 6),
            Text(
              _isSaving ? 'Uploading…' : 'Stop & Save',
              style: GoogleFonts.manrope(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
