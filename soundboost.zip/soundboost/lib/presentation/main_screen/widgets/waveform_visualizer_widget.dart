import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../../services/audio_pipeline_service.dart';
import '../../../theme/app_theme.dart';

class WaveformVisualizerWidget extends StatefulWidget {
  final bool isActive;

  const WaveformVisualizerWidget({super.key, required this.isActive});

  @override
  State<WaveformVisualizerWidget> createState() =>
      _WaveformVisualizerWidgetState();
}

class _WaveformVisualizerWidgetState extends State<WaveformVisualizerWidget>
    with SingleTickerProviderStateMixin {
  final AudioPipelineService _service = AudioPipelineService();
  StreamSubscription<List<double>>? _waveformSub;

  late AnimationController _decayController;
  final int _barCount = 28;
  late List<double> _barHeights;

  @override
  void initState() {
    super.initState();
    _barHeights = List.filled(_barCount, 0.08);

    _decayController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 80),
    )..addListener(_decayBars);

    if (widget.isActive) _subscribe();
  }

  void _subscribe() {
    _decayController.stop();
    _waveformSub = _service.waveformStream.listen((bars) {
      if (!mounted) return;
      setState(() {
        for (int i = 0; i < _barCount && i < bars.length; i++) {
          // Amplify for visual clarity
          final target = (bars[i] * 4.0).clamp(0.06, 0.95);
          // Smooth: fast attack, slow decay
          _barHeights[i] = _barHeights[i] < target
              ? target
              : _barHeights[i] * 0.75 + target * 0.25;
        }
      });
    });
  }

  void _decayBars() {
    if (!mounted) return;
    setState(() {
      _barHeights = _barHeights.map((h) => math.max(0.08, h - 0.015)).toList();
    });
  }

  @override
  void didUpdateWidget(WaveformVisualizerWidget old) {
    super.didUpdateWidget(old);
    if (widget.isActive && !old.isActive) {
      _subscribe();
    } else if (!widget.isActive && old.isActive) {
      _waveformSub?.cancel();
      _waveformSub = null;
      // Decay bars to baseline
      _decayController.repeat();
    }
  }

  @override
  void dispose() {
    _waveformSub?.cancel();
    _decayController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: List.generate(_barCount, (i) {
          final height = _barHeights[i];
          return AnimatedContainer(
            duration: const Duration(milliseconds: 60),
            curve: Curves.easeOutCubic,
            width: (MediaQuery.of(context).size.width - 56) / _barCount - 2,
            height: (height * 52).clamp(4.0, 52.0),
            decoration: BoxDecoration(
              color: widget.isActive
                  ? AppTheme.primary.withOpacity(0.3 + height * 0.7)
                  : theme.colorScheme.outlineVariant,
              borderRadius: BorderRadius.circular(3),
            ),
          );
        }),
      ),
    );
  }
}
