import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../services/audio_pipeline_service.dart';
import '../../../theme/app_theme.dart';

class VoiceDetectionWidget extends StatefulWidget {
  final bool isActive;

  const VoiceDetectionWidget({super.key, required this.isActive});

  @override
  State<VoiceDetectionWidget> createState() => _VoiceDetectionWidgetState();
}

class _VoiceDetectionWidgetState extends State<VoiceDetectionWidget>
    with SingleTickerProviderStateMixin {
  final AudioPipelineService _service = AudioPipelineService();
  StreamSubscription<VoiceDetectionResult>? _sub;
  VoiceDetectionResult _result = VoiceDetectionResult.silent;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    if (widget.isActive) _subscribe();
  }

  void _subscribe() {
    _sub = _service.voiceDetectionStream.listen((result) {
      if (mounted) setState(() => _result = result);
    });
  }

  @override
  void didUpdateWidget(VoiceDetectionWidget old) {
    super.didUpdateWidget(old);
    if (widget.isActive && !old.isActive) {
      _subscribe();
    } else if (!widget.isActive && old.isActive) {
      _sub?.cancel();
      _sub = null;
      if (mounted) setState(() => _result = VoiceDetectionResult.silent);
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  Color get _indicatorColor {
    if (!widget.isActive) return Colors.grey.shade400;
    if (_result.isVoiceDetected) {
      return _result.voiceConfidence >= 0.7
          ? const Color(0xFF22C55E)
          : const Color(0xFFF59E0B);
    }
    if (_result.rmsLevel > 0.005) return const Color(0xFF6366F1);
    return Colors.grey.shade400;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isVoice = widget.isActive && _result.isVoiceDetected;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: isVoice
              ? _indicatorColor.withAlpha(102)
              : theme.colorScheme.outline,
          width: isVoice ? 1.5 : 1.0,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: _pulseAnim,
                builder: (context, child) => Transform.scale(
                  scale: isVoice ? _pulseAnim.value : 1.0,
                  child: child,
                ),
                child: Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _indicatorColor,
                    boxShadow: isVoice
                        ? [
                            BoxShadow(
                              color: _indicatorColor.withAlpha(128),
                              blurRadius: 6,
                              spreadRadius: 1,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Voice Detection',
                style: GoogleFonts.manrope(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                  letterSpacing: 0.3,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _indicatorColor.withAlpha(31),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Text(
                  widget.isActive ? _result.voiceLabel : 'Inactive',
                  style: GoogleFonts.manrope(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: widget.isActive ? _indicatorColor : Colors.grey,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Confidence bar
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Voice Confidence',
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        color: theme.colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4.0),
                      child: LinearProgressIndicator(
                        value: widget.isActive ? _result.voiceConfidence : 0.0,
                        minHeight: 5,
                        backgroundColor: theme.colorScheme.outline.withAlpha(
                          77,
                        ),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _indicatorColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Signal Level',
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        color: theme.colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4.0),
                      child: LinearProgressIndicator(
                        value: widget.isActive
                            ? (_result.rmsLevel * 10).clamp(0.0, 1.0)
                            : 0.0,
                        minHeight: 5,
                        backgroundColor: theme.colorScheme.outline.withAlpha(
                          77,
                        ),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.primary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
