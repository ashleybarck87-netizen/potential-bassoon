import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';
import '../main_screen.dart';

class PresetSelectorWidget extends StatelessWidget {
  final SoundPreset selectedPreset;
  final ValueChanged<SoundPreset> onPresetChanged;

  const PresetSelectorWidget({
    super.key,
    required this.selectedPreset,
    required this.onPresetChanged,
  });

  static const List<_PresetItem> _presets = [
    _PresetItem(SoundPreset.voice, 'Voice', 'record_voice_over'),
    _PresetItem(SoundPreset.nature, 'Nature', 'forest'),
    _PresetItem(SoundPreset.hunt, 'Hunt', 'hearing'),
    _PresetItem(SoundPreset.music, 'Music', 'music_note'),
    _PresetItem(SoundPreset.custom, 'Custom', 'tune'),
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 52,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: _presets.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final item = _presets[i];
          final isSelected = selectedPreset == item.preset;
          return _PresetChip(
            item: item,
            isSelected: isSelected,
            onTap: () => onPresetChanged(item.preset),
          );
        },
      ),
    );
  }
}

class _PresetChip extends StatefulWidget {
  final _PresetItem item;
  final bool isSelected;
  final VoidCallback onTap;

  const _PresetChip({
    required this.item,
    required this.isSelected,
    required this.onTap,
  });

  @override
  State<_PresetChip> createState() => _PresetChipState();
}

class _PresetChipState extends State<_PresetChip>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scaleAnim = Tween<double>(
      begin: 1.0,
      end: 0.94,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: ScaleTransition(
        scale: _scaleAnim,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
          decoration: BoxDecoration(
            color: widget.isSelected
                ? AppTheme.primary
                : theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: widget.isSelected
                  ? AppTheme.primary
                  : theme.colorScheme.outline,
              width: 1.5,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomIconWidget(
                iconName: widget.item.iconName,
                color: widget.isSelected
                    ? Colors.white
                    : theme.colorScheme.onSurfaceVariant,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                widget.item.label,
                style: GoogleFonts.manrope(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: widget.isSelected
                      ? Colors.white
                      : theme.colorScheme.onSurface,
                  letterSpacing: 0.1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PresetItem {
  final SoundPreset preset;
  final String label;
  final String iconName;
  const _PresetItem(this.preset, this.label, this.iconName);
}
