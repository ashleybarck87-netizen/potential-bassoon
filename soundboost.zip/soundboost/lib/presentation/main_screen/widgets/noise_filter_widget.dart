import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class NoiseFilterWidget extends StatelessWidget {
  final bool isEnabled;
  final double reductionPercent;
  final ValueChanged<bool> onToggle;
  final ValueChanged<double> onReductionChanged;

  const NoiseFilterWidget({
    super.key,
    required this.isEnabled,
    required this.reductionPercent,
    required this.onToggle,
    required this.onReductionChanged,
  });

  String _reductionLabel(double v) {
    if (v < 30) return 'Light';
    if (v < 60) return 'Moderate';
    if (v < 80) return 'Strong';
    return 'Max';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isEnabled
              ? AppTheme.primary.withAlpha(89)
              : theme.colorScheme.outline,
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: isEnabled
                      ? AppTheme.primary.withAlpha(26)
                      : theme.colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: 'noise_aware',
                  color: isEnabled
                      ? AppTheme.primary
                      : theme.colorScheme.onSurfaceVariant,
                  size: 17,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text('Noise Filter', style: theme.textTheme.titleSmall),
              ),
              Switch(
                value: isEnabled,
                onChanged: (v) {
                  HapticFeedback.selectionClick();
                  onToggle(v);
                },
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Reduction value
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                reductionPercent.toStringAsFixed(0),
                style: GoogleFonts.manrope(
                  fontSize: 44,
                  fontWeight: FontWeight.w800,
                  color: isEnabled
                      ? AppTheme.primary
                      : theme.colorScheme.onSurfaceVariant,
                  letterSpacing: -2,
                  fontFeatures: [const FontFeature.tabularFigures()],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(
                  ' % blocked',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          // Reduction level indicator chips
          Row(
            children: ['Light', 'Moderate', 'Strong', 'Max'].map((label) {
              final active = _reductionLabel(reductionPercent) == label;
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: active && isEnabled
                        ? AppTheme.primary.withAlpha(31)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: active && isEnabled
                          ? AppTheme.primary
                          : theme.colorScheme.outlineVariant,
                      width: 1,
                    ),
                  ),
                  child: Text(
                    label,
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: active && isEnabled
                          ? AppTheme.primary
                          : theme.colorScheme.onSurfaceVariant,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 10),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: isEnabled
                  ? AppTheme.primary
                  : theme.colorScheme.outline,
              thumbColor: isEnabled
                  ? AppTheme.primary
                  : theme.colorScheme.outline,
              overlayColor: AppTheme.primary.withAlpha(26),
              trackHeight: 3,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
            ),
            child: Slider(
              value: reductionPercent,
              min: 0,
              max: 100,
              divisions: 20,
              onChanged: isEnabled
                  ? (v) {
                      HapticFeedback.selectionClick();
                      onReductionChanged(v);
                    }
                  : null,
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Off',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                'Max',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
