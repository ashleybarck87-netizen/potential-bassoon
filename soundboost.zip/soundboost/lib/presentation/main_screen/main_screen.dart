import 'package:flutter/services.dart';

import '../../core/app_export.dart';
import '../../services/audio_pipeline_service.dart';
import './widgets/gain_slider_widget.dart';
import './widgets/hero_control_widget.dart';
import './widgets/noise_filter_widget.dart';
import './widgets/noise_reduction_export_widget.dart';
import './widgets/preset_selector_widget.dart';
import './widgets/voice_detection_widget.dart';
import './widgets/waveform_visualizer_widget.dart';

// TODO: Replace with Riverpod/Bloc for production audio state management

enum SoundPreset { voice, nature, hunt, music, custom }

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  bool _isAmplifying = false;
  bool _isBackgroundMode = false;
  SoundPreset _selectedPreset = SoundPreset.nature;
  double _gainDb = 12.0;
  double _noiseReduction = 65.0;
  bool _noiseFilterEnabled = true;

  final AudioPipelineService _audioPipeline = AudioPipelineService();

  late AnimationController _activationController;
  late Animation<double> _activationScale;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _activationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );
    _activationScale = Tween<double>(begin: 0.95, end: 1.0).animate(
      CurvedAnimation(parent: _activationController, curve: Curves.easeOutBack),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _activationController.dispose();
    if (_isAmplifying) _audioPipeline.stopPipeline();
    super.dispose();
  }

  /// Called when the app lifecycle state changes (foreground/background).
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (!_isAmplifying) return;

    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
        // App going to background — keep pipeline alive, re-assert audio session
        _audioPipeline.pausePipeline();
        break;
      case AppLifecycleState.resumed:
        // App returning to foreground — restore speaker routing
        _audioPipeline.resumePipeline();
        break;
      case AppLifecycleState.detached:
      case AppLifecycleState.hidden:
        break;
    }
  }

  Future<void> _toggleAmplification() async {
    HapticFeedback.mediumImpact();
    if (!_isAmplifying) {
      final started = await _audioPipeline.startPipeline();
      if (!started) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Microphone permission required to start amplification.',
              ),
              duration: Duration(seconds: 2),
            ),
          );
        }
        return;
      }
      setState(() => _isAmplifying = true);
      _activationController.forward(from: 0);
    } else {
      await _audioPipeline.stopPipeline();
      setState(() => _isAmplifying = false);
      _activationController.reverse();
    }
  }

  void _onPresetChanged(SoundPreset preset) {
    HapticFeedback.selectionClick();
    setState(() {
      _selectedPreset = preset;
      switch (preset) {
        case SoundPreset.voice:
          _gainDb = 18.0;
          _noiseReduction = 75.0;
          break;
        case SoundPreset.nature:
          _gainDb = 12.0;
          _noiseReduction = 60.0;
          break;
        case SoundPreset.hunt:
          _gainDb = 22.0;
          _noiseReduction = 80.0;
          break;
        case SoundPreset.music:
          _gainDb = 8.0;
          _noiseReduction = 40.0;
          break;
        case SoundPreset.custom:
          break;
      }
    });
    _audioPipeline.setNoiseReductionStrength(_noiseReduction / 100.0);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildFloatingAppBar(context, theme),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.symmetric(
                  horizontal: isTablet ? 32 : 20,
                  vertical: 8,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 8),
                    // Hero control
                    ScaleTransition(
                      scale: _activationScale,
                      child: HeroControlWidget(
                        isAmplifying: _isAmplifying,
                        gainDb: _gainDb,
                        isBackgroundMode: _isBackgroundMode,
                        onToggle: () => _toggleAmplification(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Waveform visualizer (real PCM data)
                    WaveformVisualizerWidget(isActive: _isAmplifying),
                    const SizedBox(height: 12),
                    // Voice detection panel
                    VoiceDetectionWidget(isActive: _isAmplifying),
                    const SizedBox(height: 20),
                    // Preset selector
                    Text(
                      'Sound Preset',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 10),
                    PresetSelectorWidget(
                      selectedPreset: _selectedPreset,
                      onPresetChanged: _onPresetChanged,
                    ),
                    const SizedBox(height: 20),
                    // Gain + Noise cards
                    if (isTablet)
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: GainSliderWidget(
                              gainDb: _gainDb,
                              isActive: _isAmplifying,
                              onGainChanged: (v) => setState(() => _gainDb = v),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: NoiseFilterWidget(
                              isEnabled: _noiseFilterEnabled,
                              reductionPercent: _noiseReduction,
                              onToggle: (v) {
                                setState(() => _noiseFilterEnabled = v);
                                _audioPipeline.setNoiseReductionEnabled(v);
                              },
                              onReductionChanged: (v) {
                                setState(() => _noiseReduction = v);
                                _audioPipeline.setNoiseReductionStrength(
                                  v / 100.0,
                                );
                              },
                            ),
                          ),
                        ],
                      )
                    else ...[
                      GainSliderWidget(
                        gainDb: _gainDb,
                        isActive: _isAmplifying,
                        onGainChanged: (v) => setState(() => _gainDb = v),
                      ),
                      const SizedBox(height: 16),
                      NoiseFilterWidget(
                        isEnabled: _noiseFilterEnabled,
                        reductionPercent: _noiseReduction,
                        onToggle: (v) {
                          setState(() => _noiseFilterEnabled = v);
                          _audioPipeline.setNoiseReductionEnabled(v);
                        },
                        onReductionChanged: (v) {
                          setState(() => _noiseReduction = v);
                          _audioPipeline.setNoiseReductionStrength(v / 100.0);
                        },
                      ),
                    ],
                    const SizedBox(height: 16),
                    // Export clean audio (spectral subtraction download)
                    NoiseReductionExportWidget(isAmplifying: _isAmplifying),
                    const SizedBox(height: 24),
                    // Background mode banner
                    _buildBackgroundModeBanner(context, theme),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingAppBar(BuildContext context, ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
      child: Row(
        children: [
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: AppTheme.primary,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const CustomIconWidget(
                  iconName: 'hearing',
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                'SoundBoost',
                style: GoogleFonts.manrope(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.onSurface,
                  letterSpacing: -0.5,
                ),
              ),
            ],
          ),
          const Spacer(),
          GestureDetector(
            onTap: () =>
                Navigator.pushNamed(context, AppRoutes.recordingsLibraryScreen),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline,
                  width: 1.5,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'folder_open',
                color: theme.colorScheme.onSurface,
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () =>
                Navigator.pushNamed(context, AppRoutes.recordingScreen),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline,
                  width: 1.5,
                ),
              ),
              child: const CustomIconWidget(
                iconName: 'fiber_manual_record',
                color: Colors.redAccent,
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => Navigator.pushNamed(context, AppRoutes.settingsScreen),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline,
                  width: 1.5,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'settings',
                color: theme.colorScheme.onSurface,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackgroundModeBanner(BuildContext context, ThemeData theme) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() => _isBackgroundMode = !_isBackgroundMode);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _isBackgroundMode
              ? AppTheme.primary.withAlpha(20)
              : theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(14.0),
          border: Border.all(
            color: _isBackgroundMode
                ? AppTheme.primary.withAlpha(77)
                : theme.colorScheme.outline,
            width: 1.5,
          ),
        ),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: _isBackgroundMode
                  ? 'headphones'
                  : 'headphones_outlined',
              color: _isBackgroundMode
                  ? AppTheme.primary
                  : theme.colorScheme.onSurfaceVariant,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Background Mode',
                    style: GoogleFonts.manrope(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: _isBackgroundMode
                          ? AppTheme.primary
                          : theme.colorScheme.onSurface,
                    ),
                  ),
                  Text(
                    _isBackgroundMode
                        ? 'Amplification runs with screen off'
                        : 'Keep amplifying when screen is off',
                    style: GoogleFonts.manrope(
                      fontSize: 11,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Switch(
              value: _isBackgroundMode,
              onChanged: (v) {
                HapticFeedback.lightImpact();
                setState(() => _isBackgroundMode = v);
              },
              activeColor: AppTheme.primary,
            ),
          ],
        ),
      ),
    );
  }
}
