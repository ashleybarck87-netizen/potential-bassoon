import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:fftea/fftea.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:record/record.dart';

/// Voice activity detection result
class VoiceDetectionResult {
  final bool isVoiceDetected;
  final double voiceConfidence; // 0.0 - 1.0
  final double rmsLevel; // Root mean square amplitude
  final double peakLevel; // Peak amplitude
  final String voiceLabel; // e.g. "Voice", "Ambient", "Silence"

  const VoiceDetectionResult({
    required this.isVoiceDetected,
    required this.voiceConfidence,
    required this.rmsLevel,
    required this.peakLevel,
    required this.voiceLabel,
  });

  static const VoiceDetectionResult silent = VoiceDetectionResult(
    isVoiceDetected: false,
    voiceConfidence: 0.0,
    rmsLevel: 0.0,
    peakLevel: 0.0,
    voiceLabel: 'Silence',
  );
}

/// PCM audio frame from the microphone stream
class PcmAudioFrame {
  final List<int> samples; // Raw PCM samples (16-bit signed)
  final int sampleRate;
  final int channels;
  final DateTime timestamp;

  const PcmAudioFrame({
    required this.samples,
    required this.sampleRate,
    required this.channels,
    required this.timestamp,
  });
}

/// Real-time audio pipeline service
/// Captures PCM stream from microphone, performs spectral subtraction noise
/// reduction, voice activity detection, and records processed audio for export.
class AudioPipelineService {
  static final AudioPipelineService _instance =
      AudioPipelineService._internal();
  factory AudioPipelineService() => _instance;
  AudioPipelineService._internal() {
    _hann = Float64List.fromList(_hannWindow(_fftSize));
    _overlapBuffer = Float64List(_fftSize);
    _windowAccumulation = Float64List(_fftSize);
    _magnitude = Float64List(_fftSize ~/ 2 + 1);
    _phase = Float64List(_fftSize ~/ 2 + 1);
  }

  final AudioRecorder _recorder = AudioRecorder();

  // ── Speaker playback via flutter_sound ───────────────────────────────────
  FlutterSoundPlayer? _player;

  // Stream controllers
  final StreamController<PcmAudioFrame> _pcmStreamController =
      StreamController<PcmAudioFrame>.broadcast();
  final StreamController<VoiceDetectionResult> _voiceDetectionController =
      StreamController<VoiceDetectionResult>.broadcast();
  final StreamController<List<double>> _waveformController =
      StreamController<List<double>>.broadcast();

  StreamSubscription<Uint8List>? _audioStreamSubscription;
  Timer? _silenceTimer;

  bool _isRecording = false;
  bool _isInitialized = false;

  // Audio config
  static const int _sampleRate = 16000;
  static const int _channels = 1;
  static const int _bitDepth = 16;

  // Voice detection thresholds
  static const double _voiceRmsThreshold = 0.015;
  static const double _ambientRmsThreshold = 0.005;
  static const double _voiceFreqLow = 85.0;
  static const double _voiceFreqHigh = 3400.0;

  // State
  VoiceDetectionResult _lastResult = VoiceDetectionResult.silent;
  final List<double> _rmsHistory = [];
  static const int _rmsHistorySize = 10;

  // ── Spectral Subtraction ──────────────────────────────────────────────────
  static const int _fftSize = 512;
  static const int _calibrationFrames = 20;
  static const double _overSubtraction = 2.0;
  static const double _spectralFloor = 0.002;

  // ── FFT & spectral processing buffers ────────────────────────────────────
  final FFT _fft = FFT(_fftSize);

  late final Float64List _hann;
  late final Float64List _overlapBuffer;
  late final Float64List _windowAccumulation;

  final List<double> _streamBuffer = [];

  late final Float64List _magnitude;
  late final Float64List _phase;

  List<double> _noiseFloorMagnitude = List.filled(_fftSize ~/ 2 + 1, 0.0);
  final List<List<double>> _calibrationBuffer = [];
  bool _noiseFloorEstimated = false;
  bool _noiseReductionEnabled = true;
  double _noiseReductionStrength = 0.65;
  int _speechHangoverFrames = 0;

  // ── Recording buffer for WAV export ──────────────────────────────────────
  final List<int> _recordedSamples = [];
  bool _isCapturingForExport = false;

  // Public streams
  Stream<PcmAudioFrame> get pcmStream => _pcmStreamController.stream;
  Stream<VoiceDetectionResult> get voiceDetectionStream =>
      _voiceDetectionController.stream;
  Stream<List<double>> get waveformStream => _waveformController.stream;

  bool get isRecording => _isRecording;
  bool get noiseReductionEnabled => _noiseReductionEnabled;
  bool get noiseFloorEstimated => _noiseFloorEstimated;
  VoiceDetectionResult get lastVoiceResult => _lastResult;

  void setNoiseReductionEnabled(bool enabled) {
    _noiseReductionEnabled = enabled;
  }

  void setNoiseReductionStrength(double strength) {
    _noiseReductionStrength = strength.clamp(0.0, 1.0);
  }

  /// Reset noise floor so it will be re-estimated on next pipeline start
  void resetNoiseFloor() {
    _calibrationBuffer.clear();
    _noiseFloorEstimated = false;
    _noiseFloorMagnitude = List.filled(_fftSize ~/ 2 + 1, 0.0);
  }

  /// Start capturing processed audio for WAV export
  void startExportCapture() {
    _recordedSamples.clear();
    _isCapturingForExport = true;
  }

  /// Stop capture and return WAV bytes
  Uint8List? stopExportCapture() {
    _isCapturingForExport = false;
    if (_recordedSamples.isEmpty) return null;
    return _buildWavBytes(_recordedSamples, _sampleRate, _channels);
  }

  bool get isCapturingForExport => _isCapturingForExport;
  int get capturedSampleCount => _recordedSamples.length;

  /// Configure audio session for speaker/headphone output (not earpiece).
  Future<void> _configureSpeakerOutput() async {
    if (kIsWeb) return;
    try {
      final session = await AudioSession.instance;
      await session.configure(
        AudioSessionConfiguration(
          avAudioSessionCategory: AVAudioSessionCategory.playAndRecord,
          avAudioSessionCategoryOptions:
              AVAudioSessionCategoryOptions.defaultToSpeaker |
              AVAudioSessionCategoryOptions.allowBluetooth |
              AVAudioSessionCategoryOptions.allowBluetoothA2dp,
          // Use measurement mode — does NOT reroute to earpiece
          avAudioSessionMode: AVAudioSessionMode.measurement,
          avAudioSessionRouteSharingPolicy:
              AVAudioSessionRouteSharingPolicy.defaultPolicy,
          avAudioSessionSetActiveOptions: AVAudioSessionSetActiveOptions.none,
          androidAudioAttributes: AndroidAudioAttributes(
            contentType: AndroidAudioContentType.music,
            flags: AndroidAudioFlags.none,
            usage: AndroidAudioUsage.media,
          ),
          androidAudioFocusGainType: AndroidAudioFocusGainType.gain,
          androidWillPauseWhenDucked: false,
        ),
      );
      await session.setActive(true);
    } catch (e) {
      debugPrint('AudioPipelineService: Speaker config error: $e');
    }
  }

  /// Start flutter_sound player in streaming mode for real-time PCM output.
  Future<void> _startSpeakerPlayback() async {
    if (kIsWeb) return;
    try {
      _player = FlutterSoundPlayer();
      await _player!.openPlayer();

      await _player!.startPlayerFromStream(
        codec: Codec.pcm16,
        interleaved: true,
        numChannels: 1,
        sampleRate: _sampleRate,
        bufferSize: 8192,
      );

      debugPrint('AudioPipelineService: flutter_sound player started');
    } catch (e) {
      debugPrint('AudioPipelineService: Speaker playback start error: $e');
      await _stopSpeakerPlayback();
    }
  }

  /// Feed raw PCM int16 bytes to the flutter_sound player via foodSink.
  void _feedPcmToPlayer(List<int> pcmInt16Samples) {
    if (_player == null) return;
    if (!(_player!.isPlaying)) return;

    // Pack int16 samples into bytes (little-endian)
    final bytes = ByteData(pcmInt16Samples.length * 2);
    for (int i = 0; i < pcmInt16Samples.length; i++) {
      bytes.setInt16(
        i * 2,
        pcmInt16Samples[i].clamp(-32768, 32767),
        Endian.little,
      );
    }
    try {
      _player!.uint8ListSink?.add(bytes.buffer.asUint8List());
    } catch (e) {
      debugPrint('AudioPipelineService: feedPcm error: $e');
    }
  }

  /// Stop and dispose the flutter_sound player.
  Future<void> _stopSpeakerPlayback() async {
    try {
      await _player?.stopPlayer();
      await _player?.closePlayer();
    } catch (_) {}
    _player = null;
  }

  /// Initialize and start the audio pipeline
  Future<bool> startPipeline() async {
    if (_isRecording) return true;

    try {
      final hasPermission = await _recorder.hasPermission();
      if (!hasPermission) return false;

      // Configure speaker output before starting recording
      await _configureSpeakerOutput();

      resetNoiseFloor();

      // Start speaker playback
      await _startSpeakerPlayback();

      final stream = await _recorder.startStream(
        const RecordConfig(
          encoder: AudioEncoder.pcm16bits,
          sampleRate: _sampleRate,
          numChannels: _channels,
          bitRate: _sampleRate * _channels * _bitDepth,
          autoGain: true,
          echoCancel: true,
          noiseSuppress: false,
        ),
      );

      _audioStreamSubscription = stream.listen(
        _onAudioData,
        onError: _onAudioError,
        cancelOnError: false,
      );

      _isRecording = true;
      _isInitialized = true;
      return true;
    } catch (e) {
      debugPrint('AudioPipelineService: Failed to start pipeline: $e');
      await _stopSpeakerPlayback();
      return false;
    }
  }

  /// Stop the audio pipeline
  Future<void> stopPipeline() async {
    if (!_isRecording) return;
    try {
      await _audioStreamSubscription?.cancel();
      _audioStreamSubscription = null;
      await _recorder.stop();
      _isRecording = false;
      _isCapturingForExport = false;
      _silenceTimer?.cancel();
      _silenceTimer = null;
      _rmsHistory.clear();

      // Stop speaker playback
      await _stopSpeakerPlayback();

      // Release audio session
      if (!kIsWeb) {
        try {
          final session = await AudioSession.instance;
          await session.setActive(false);
        } catch (_) {}
      }

      _lastResult = VoiceDetectionResult.silent;
      if (!_voiceDetectionController.isClosed) {
        _voiceDetectionController.add(_lastResult);
      }
      if (!_waveformController.isClosed) {
        _waveformController.add(List.filled(28, 0.0));
      }
    } catch (e) {
      debugPrint('AudioPipelineService: Failed to stop pipeline: $e');
    }
  }

  /// Pause pipeline without fully stopping (used when app goes to background)
  Future<void> pausePipeline() async {
    if (!_isRecording) return;
    try {
      if (!kIsWeb) {
        try {
          final session = await AudioSession.instance;
          await session.setActive(true);
        } catch (_) {}
      }
    } catch (e) {
      debugPrint('AudioPipelineService: pausePipeline error: $e');
    }
  }

  /// Resume pipeline after returning from background
  Future<void> resumePipeline() async {
    if (!_isRecording) return;
    try {
      if (!kIsWeb) {
        await _configureSpeakerOutput();
      }
    } catch (e) {
      debugPrint('AudioPipelineService: resumePipeline error: $e');
    }
  }

  /// Process incoming raw PCM bytes
  void _onAudioData(Uint8List rawBytes) {
    if (rawBytes.isEmpty) return;

    final samples = _bytesToSamples(rawBytes);
    if (samples.isEmpty) return;

    // Normalize to [-1.0, 1.0]
    final normalized = samples.map((s) => s / 32768.0).toList();

    // DEBUG: log input RMS
    final inputRms = _computeRms(normalized);
    debugPrint(
      'AudioPipeline [INPUT] RMS=$inputRms  samples=${normalized.length}',
    );

    // ── Spectral Subtraction ──────────────────────────────────────────────
    List<double> processedNormalized;
    if (_noiseReductionEnabled) {
      processedNormalized = _applySpectralSubtraction(normalized);
    } else {
      processedNormalized = normalized;
    }

    // DEBUG: log output RMS and buffer state
    final outputRms = _computeRms(processedNormalized);
    debugPrint(
      'AudioPipeline [OUTPUT] RMS=$outputRms  processedLen=${processedNormalized.length}  streamBuf=${_streamBuffer.length}',
    );

    // Convert processed back to int16 for PCM frame & export
    final processedSamples = processedNormalized
        .map((s) => (s * 32768.0).round().clamp(-32768, 32767))
        .toList();

    // ── Feed processed PCM to speaker ────────────────────────────────────
    if (processedSamples.isNotEmpty) {
      _feedPcmToPlayer(processedSamples);
    }

    // Accumulate for WAV export
    if (_isCapturingForExport) {
      _recordedSamples.addAll(processedSamples);
    }

    // Emit PCM frame (processed)
    final frame = PcmAudioFrame(
      samples: processedSamples,
      sampleRate: _sampleRate,
      channels: _channels,
      timestamp: DateTime.now(),
    );
    if (!_pcmStreamController.isClosed) {
      _pcmStreamController.add(frame);
    }

    // Compute RMS and peak on processed signal
    final rms = _computeRms(processedNormalized);
    final peak = processedNormalized.fold(0.0, (m, s) => math.max(m, s.abs()));

    _rmsHistory.add(rms);
    if (_rmsHistory.length > _rmsHistorySize) _rmsHistory.removeAt(0);
    final smoothedRms =
        _rmsHistory.reduce((a, b) => a + b) / _rmsHistory.length;

    final voiceResult = _detectVoice(processedNormalized, smoothedRms, peak);
    _lastResult = voiceResult;
    if (!_voiceDetectionController.isClosed) {
      _voiceDetectionController.add(voiceResult);
    }

    final waveform = _computeWaveformBars(processedNormalized, 28);
    if (!_waveformController.isClosed) {
      _waveformController.add(waveform);
    }
  }

  void _onAudioError(Object error) {
    debugPrint('AudioPipelineService: Stream error: $error');
  }

  // ── Spectral Subtraction Implementation ────────────────────────────────────

  List<double> _applySpectralSubtraction(List<double> input) {
    _streamBuffer.addAll(input);

    final output = <double>[];
    final hopSize = _fftSize ~/ 2;
    // Number of useful bins from realFft (DC + positive freqs + Nyquist)
    final bins = _fftSize ~/ 2 + 1;

    while (_streamBuffer.length >= _fftSize) {
      final frame = Float64List(_fftSize);

      for (int i = 0; i < _fftSize; i++) {
        frame[i] = _streamBuffer[i] * _hann[i];
      }

      // FFT — returns Float64x2List of length _fftSize (full complex array)
      final spectrum = _fft.realFft(frame);

      // Only process the first `bins` elements (DC through Nyquist).
      // spectrum[0..bins-1] are the unique bins; the rest are conjugates.
      for (int k = 0; k < bins; k++) {
        final re = spectrum[k].x;
        final im = spectrum[k].y;

        _magnitude[k] = math.sqrt(re * re + im * im);
        _phase[k] = math.atan2(im, re);
      }

      // DEBUG: log average FFT magnitude
      final avgMag = _magnitude.reduce((a, b) => a + b) / bins;
      debugPrint(
        'AudioPipeline [FFT] avgMag=$avgMag  noiseEstimated=$_noiseFloorEstimated  calibBuf=${_calibrationBuffer.length}',
      );

      // Calibration phase — collect noise floor samples
      if (!_noiseFloorEstimated) {
        _calibrationBuffer.add(List<double>.from(_magnitude));

        if (_calibrationBuffer.length >= _calibrationFrames) {
          _estimateNoiseFloorFast();
        }

        // During calibration emit the unwindowed raw samples so RMS is non-zero
        output.addAll(_streamBuffer.sublist(0, hopSize));
        _streamBuffer.removeRange(0, hopSize);
        continue;
      }

      final alpha = _overSubtraction * (0.5 + _noiseReductionStrength);

      // Spectral subtraction — only modify the unique bins
      for (int k = 0; k < bins; k++) {
        final noise = _noiseFloorMagnitude[k];

        double clean = _magnitude[k] - (alpha * noise);

        final floor = _spectralFloor * noise;

        clean = math.max(clean, floor);

        spectrum[k] = Float64x2(
          clean * math.cos(_phase[k]),
          clean * math.sin(_phase[k]),
        );
      }

      // Reconstruct conjugate bins so realInverseFft gets a valid full spectrum
      for (int k = bins; k < _fftSize; k++) {
        final mirror = _fftSize - k;
        spectrum[k] = Float64x2(spectrum[mirror].x, -spectrum[mirror].y);
      }

      // Inverse FFT — fftea's realInverseFft normalises by 1/N internally
      final reconstructed = _fft.realInverseFft(spectrum);

      // DEBUG: log reconstructed peak
      final recPeak = reconstructed.fold(0.0, (m, s) => math.max(m, s.abs()));
      debugPrint('AudioPipeline [IFFT] recPeak=$recPeak');

      // Overlap-add
      for (int i = 0; i < _fftSize; i++) {
        _overlapBuffer[i] += reconstructed[i] * _hann[i];
        _windowAccumulation[i] += _hann[i] * _hann[i];
      }

      // Emit hop-sized chunk
      for (int i = 0; i < hopSize; i++) {
        final norm = _windowAccumulation[i] > 1e-9
            ? _overlapBuffer[i] / _windowAccumulation[i]
            : 0.0;

        output.add(norm.clamp(-1.0, 1.0));
      }

      // DEBUG: log overlap output RMS for this hop
      if (output.length >= hopSize) {
        final hopSlice = output.sublist(output.length - hopSize);
        final hopRms = _computeRms(hopSlice);
        debugPrint(
          'AudioPipeline [OLA] hopRms=$hopRms  windowAccum[0]=${_windowAccumulation[0]}',
        );
      }

      // Shift overlap buffers
      for (int i = 0; i < hopSize; i++) {
        _overlapBuffer[i] = _overlapBuffer[i + hopSize];
        _windowAccumulation[i] = _windowAccumulation[i + hopSize];
      }

      for (int i = hopSize; i < _fftSize; i++) {
        _overlapBuffer[i] = 0.0;
        _windowAccumulation[i] = 0.0;
      }

      _streamBuffer.removeRange(0, hopSize);
    }

    return output;
  }

  void _estimateNoiseFloorFast() {
    final bins = _fftSize ~/ 2 + 1;

    _noiseFloorMagnitude = List<double>.filled(bins, 0.0);

    for (final frame in _calibrationBuffer) {
      for (int k = 0; k < bins; k++) {
        _noiseFloorMagnitude[k] += frame[k];
      }
    }

    final count = _calibrationBuffer.length;

    for (int k = 0; k < bins; k++) {
      _noiseFloorMagnitude[k] /= count;
    }

    _noiseFloorEstimated = true;
    _calibrationBuffer.clear();

    debugPrint('AudioPipelineService: Noise floor estimated');
  }

  void _estimateNoiseFloor() {
    final accumulated = List<double>.filled(_fftSize ~/ 2 + 1, 0.0);
    for (final frame in _calibrationBuffer) {
      final f64 = Float64List.fromList(frame);
      final complexOut = _fft.realFft(f64);
      for (int k = 0; k <= _fftSize ~/ 2; k++) {
        final re = complexOut[k].x;
        final im = complexOut[k].y;
        accumulated[k] += math.sqrt(re * re + im * im);
      }
    }
    final n = _calibrationBuffer.length.toDouble();
    _noiseFloorMagnitude = accumulated.map((v) => v / n).toList();
    _noiseFloorEstimated = true;
    _calibrationBuffer.clear();
    debugPrint('AudioPipelineService: Noise floor estimated from $n frames');
  }

  List<double> _hannWindow(int size) {
    return List<double>.generate(
      size,
      (n) => 0.5 * (1.0 - math.cos(2.0 * math.pi * n / (size - 1))),
    );
  }

  // ── WAV Builder ────────────────────────────────────────────────────────────

  Uint8List _buildWavBytes(List<int> samples, int sampleRate, int numChannels) {
    final byteRate = sampleRate * numChannels * 2;
    final dataSize = samples.length * 2;
    final fileSize = 44 + dataSize;

    final buffer = ByteData(fileSize);
    int offset = 0;

    void writeString(String s) {
      for (final c in s.codeUnits) {
        buffer.setUint8(offset++, c);
      }
    }

    void writeUint32(int v) {
      buffer.setUint32(offset, v, Endian.little);
      offset += 4;
    }

    void writeUint16(int v) {
      buffer.setUint16(offset, v, Endian.little);
      offset += 2;
    }

    writeString('RIFF');
    writeUint32(fileSize - 8);
    writeString('WAVE');
    writeString('fmt ');
    writeUint32(16);
    writeUint16(1);
    writeUint16(numChannels);
    writeUint32(sampleRate);
    writeUint32(byteRate);
    writeUint16(numChannels * 2);
    writeUint16(16);
    writeString('data');
    writeUint32(dataSize);
    for (final s in samples) {
      final clamped = s.clamp(-32768, 32767);
      buffer.setInt16(offset, clamped, Endian.little);
      offset += 2;
    }

    return buffer.buffer.asUint8List();
  }

  // ── Voice Detection ────────────────────────────────────────────────────────

  List<int> _bytesToSamples(Uint8List bytes) {
    final samples = <int>[];
    for (int i = 0; i + 1 < bytes.length; i += 2) {
      int sample = bytes[i] | (bytes[i + 1] << 8);
      if (sample >= 32768) sample -= 65536;
      samples.add(sample);
    }
    return samples;
  }

  double _computeRms(List<double> samples) {
    if (samples.isEmpty) return 0.0;
    final sumSq = samples.fold(0.0, (sum, s) => sum + s * s);
    return math.sqrt(sumSq / samples.length);
  }

  VoiceDetectionResult _detectVoice(
    List<double> samples,
    double rms,
    double peak,
  ) {
    if (rms < _ambientRmsThreshold) {
      return VoiceDetectionResult(
        isVoiceDetected: false,
        voiceConfidence: 0.0,
        rmsLevel: rms,
        peakLevel: peak,
        voiceLabel: 'Silence',
      );
    }

    final zcr = _computeZeroCrossingRate(samples);
    final normalizedZcr = zcr / _sampleRate;
    final isVoiceZcr = normalizedZcr >= 0.002 && normalizedZcr <= 0.02;
    final isVoiceEnergy = rms >= _voiceRmsThreshold;
    final spectralScore = _estimateSpectralVoiceScoreFromMagnitude(
      List<double>.from(_magnitude),
      _fftSize,
    );

    double confidence = 0.0;
    if (isVoiceEnergy) confidence += 0.4;
    if (isVoiceZcr) confidence += 0.3;
    confidence += spectralScore * 0.3;
    confidence = confidence.clamp(0.0, 1.0);

    final isVoice = confidence >= 0.45;

    if (isVoice) {
      _speechHangoverFrames = 8;
    } else if (_speechHangoverFrames > 0) {
      _speechHangoverFrames--;
    }

    final smoothedVoice = isVoice || _speechHangoverFrames > 0;

    String label;
    if (!smoothedVoice && rms >= _ambientRmsThreshold) {
      label = 'Ambient';
    } else if (smoothedVoice && confidence >= 0.7) {
      label = 'Voice';
    } else if (smoothedVoice) {
      label = 'Voice (low)';
    } else {
      label = 'Ambient';
    }

    return VoiceDetectionResult(
      isVoiceDetected: smoothedVoice,
      voiceConfidence: confidence,
      rmsLevel: rms,
      peakLevel: peak,
      voiceLabel: label,
    );
  }

  double _computeZeroCrossingRate(List<double> samples) {
    if (samples.length < 2) return 0.0;
    int crossings = 0;
    for (int i = 1; i < samples.length; i++) {
      if ((samples[i] >= 0) != (samples[i - 1] >= 0)) crossings++;
    }
    return crossings.toDouble();
  }

  double _estimateSpectralVoiceScoreFromMagnitude(
    List<double> magnitude,
    int fftSize,
  ) {
    if (magnitude.isEmpty) return 0.0;

    final freqResolution = _sampleRate / fftSize;

    final voiceLowBin = (_voiceFreqLow / freqResolution).round();

    final voiceHighBin = (_voiceFreqHigh / freqResolution).round().clamp(
      0,
      magnitude.length - 1,
    );

    double voiceEnergy = 0.0;
    double totalEnergy = 0.0;

    for (int k = 1; k < magnitude.length; k++) {
      totalEnergy += magnitude[k];

      if (k >= voiceLowBin && k <= voiceHighBin) {
        voiceEnergy += magnitude[k];
      }
    }

    if (totalEnergy <= 0.0) return 0.0;

    return (voiceEnergy / totalEnergy).clamp(0.0, 1.0);
  }

  List<double> _computeWaveformBars(List<double> samples, int barCount) {
    if (samples.isEmpty) return List.filled(barCount, 0.0);
    final chunkSize = (samples.length / barCount).ceil();
    final bars = <double>[];
    for (int i = 0; i < barCount; i++) {
      final start = i * chunkSize;
      final end = math.min(start + chunkSize, samples.length);
      if (start >= samples.length) {
        bars.add(0.0);
        continue;
      }
      final chunk = samples.sublist(start, end);
      final rms = _computeRms(chunk);
      bars.add(rms.clamp(0.0, 1.0));
    }
    return bars;
  }

  void dispose() {
    stopPipeline();
    _pcmStreamController.close();
    _voiceDetectionController.close();
    _waveformController.close();
    _recorder.dispose();
    _player?.closePlayer();
  }
}