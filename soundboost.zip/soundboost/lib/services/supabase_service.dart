import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math';

class SupabaseService {
  static SupabaseService? _instance;
  static SupabaseService get instance => _instance ??= SupabaseService._();

  SupabaseService._();

  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );
  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  // Initialize Supabase - call this in main()
  static Future<void> initialize() async {
    if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
      throw Exception(
        'SUPABASE_URL and SUPABASE_ANON_KEY must be defined using --dart-define.',
      );
    }

    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }

  // Get Supabase client
  SupabaseClient get client => Supabase.instance.client;

  // ─── Device ID ───────────────────────────────────────────────────────────────

  static const _deviceIdKey = 'soundboost_device_id';

  Future<String> getDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    String? id = prefs.getString(_deviceIdKey);
    if (id == null || id.isEmpty) {
      id = _generateDeviceId();
      await prefs.setString(_deviceIdKey, id);
    }
    return id;
  }

  String _generateDeviceId() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final rng = Random.secure();
    return List.generate(32, (_) => chars[rng.nextInt(chars.length)]).join();
  }

  // ─── Preset Sync ─────────────────────────────────────────────────────────────

  /// Fetch all presets for this device from Supabase.
  /// Returns null on error.
  Future<List<Map<String, dynamic>>?> fetchPresets() async {
    try {
      final deviceId = await getDeviceId();
      final response = await client
          .from('user_presets')
          .select()
          .eq('device_id', deviceId)
          .order('created_at', ascending: true);
      return List<Map<String, dynamic>>.from(response as List);
    } catch (e) {
      return null;
    }
  }

  /// Upsert a single preset for this device.
  /// [presetKey] is the stable identifier (e.g. 'p5' or 'custom').
  Future<bool> upsertPreset({
    required String presetKey,
    required String name,
    required String description,
    required String iconName,
    required double gainDb,
    required double noiseReduction,
    required List<double> eqBands,
    bool isBuiltIn = false,
  }) async {
    try {
      final deviceId = await getDeviceId();
      await client.from('user_presets').upsert({
        'device_id': deviceId,
        'preset_key': presetKey,
        'name': name,
        'description': description,
        'icon_name': iconName,
        'gain_db': gainDb,
        'noise_reduction': noiseReduction,
        'eq_bands': eqBands,
        'is_built_in': isBuiltIn,
      }, onConflict: 'device_id,preset_key');
      return true;
    } catch (e) {
      return false;
    }
  }

  /// Upsert multiple presets at once (used for initial sync of built-in presets).
  Future<bool> upsertPresets(List<Map<String, dynamic>> presets) async {
    try {
      final deviceId = await getDeviceId();
      final rows = presets.map((p) {
        final eqBands =
            p['eqBands'] as List<double>? ?? [0.0, 0.0, 0.0, 0.0, 0.0];
        return {
          'device_id': deviceId,
          'preset_key': p['id'] as String,
          'name': p['name'] as String,
          'description': p['description'] as String,
          'icon_name': p['iconName'] as String,
          'gain_db': (p['gainDb'] as num).toDouble(),
          'noise_reduction': (p['noiseReduction'] as num).toDouble(),
          'eq_bands': eqBands,
          'is_built_in': p['isBuiltIn'] as bool? ?? false,
        };
      }).toList();

      await client
          .from('user_presets')
          .upsert(rows, onConflict: 'device_id,preset_key');
      return true;
    } catch (e) {
      return false;
    }
  }

  /// Convert a Supabase row back to the app's preset map format.
  static Map<String, dynamic> rowToPresetMap(Map<String, dynamic> row) {
    final rawBands = row['eq_bands'];
    List<double> eqBands;
    if (rawBands is List) {
      eqBands = rawBands.map((e) => (e as num).toDouble()).toList();
    } else {
      eqBands = [0.0, 0.0, 0.0, 0.0, 0.0];
    }
    return {
      'id': row['preset_key'] as String,
      'name': row['name'] as String,
      'description': row['description'] as String,
      'iconName': row['icon_name'] as String,
      'gainDb': (row['gain_db'] as num).toDouble(),
      'noiseReduction': (row['noise_reduction'] as num).toDouble(),
      'eqBands': eqBands,
      'isBuiltIn': row['is_built_in'] as bool? ?? false,
    };
  }
}
