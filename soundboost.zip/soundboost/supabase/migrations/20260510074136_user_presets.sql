-- User presets table for syncing across sessions
-- Uses device_id (anonymous) since app has no auth

CREATE TABLE IF NOT EXISTS public.user_presets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    device_id TEXT NOT NULL,
    preset_key TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    icon_name TEXT NOT NULL DEFAULT 'tune',
    gain_db DOUBLE PRECISION NOT NULL DEFAULT 15.0,
    noise_reduction DOUBLE PRECISION NOT NULL DEFAULT 55.0,
    eq_bands JSONB NOT NULL DEFAULT '[0,0,0,0,0]'::jsonb,
    is_built_in BOOLEAN NOT NULL DEFAULT false,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Unique constraint: one preset per key per device
CREATE UNIQUE INDEX IF NOT EXISTS idx_user_presets_device_key
    ON public.user_presets (device_id, preset_key);

CREATE INDEX IF NOT EXISTS idx_user_presets_device_id
    ON public.user_presets (device_id);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION public.update_user_presets_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_user_presets_updated_at ON public.user_presets;
CREATE TRIGGER trg_user_presets_updated_at
    BEFORE UPDATE ON public.user_presets
    FOR EACH ROW
    EXECUTE FUNCTION public.update_user_presets_updated_at();

-- Enable RLS
ALTER TABLE public.user_presets ENABLE ROW LEVEL SECURITY;

-- Open access by device_id (no auth required)
DROP POLICY IF EXISTS "device_manage_own_presets" ON public.user_presets;
CREATE POLICY "device_manage_own_presets"
    ON public.user_presets
    FOR ALL
    TO public
    USING (true)
    WITH CHECK (true);
