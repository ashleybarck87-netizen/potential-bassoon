-- Create public storage bucket for SoundBoost recordings
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'recordings',
    'recordings',
    true,
    104857600, -- 100MB limit per file
    ARRAY['audio/wav', 'audio/x-wav', 'audio/wave', 'application/octet-stream']
)
ON CONFLICT (id) DO NOTHING;

-- RLS: Anyone can upload recordings (no auth required for this app)
DROP POLICY IF EXISTS "public_upload_recordings" ON storage.objects;
CREATE POLICY "public_upload_recordings" ON storage.objects
FOR INSERT TO public
WITH CHECK (bucket_id = 'recordings');

-- RLS: Anyone can read recordings
DROP POLICY IF EXISTS "public_read_recordings" ON storage.objects;
CREATE POLICY "public_read_recordings" ON storage.objects
FOR SELECT TO public
USING (bucket_id = 'recordings');

-- RLS: Anyone can delete recordings
DROP POLICY IF EXISTS "public_delete_recordings" ON storage.objects;
CREATE POLICY "public_delete_recordings" ON storage.objects
FOR DELETE TO public
USING (bucket_id = 'recordings');
